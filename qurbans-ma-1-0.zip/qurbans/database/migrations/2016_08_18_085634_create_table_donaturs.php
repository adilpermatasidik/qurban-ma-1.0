<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableDonaturs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      //table field
      Schema::create('donaturs', function (Blueprint $table) {
          $table->increments('id');
          $table->enum(array('Bapak','Ibu'));
          $table->string('name',255);
          $table->string('phone',255);
          $table->string('email');
          $table->text('alamat');
          $table->integer('id_user');
          $table->integer('id_kantor');
          $table->timestamps();
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
