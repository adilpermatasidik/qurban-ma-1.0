<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableOrderQurbanDetail extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      //table field
      Schema::create('order_qurban_details', function (Blueprint $table) {
          $table->increments('id');
          $table->integer('order_id');
          $table->integer('id_hewan');
          $table->integer('qty');
          $table->string('pequrban');
          $table->integer('id_pesanan');
          $table->integer('id_paymen');
          $table->integer('id_kantor');
          $table->timestamps();
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
