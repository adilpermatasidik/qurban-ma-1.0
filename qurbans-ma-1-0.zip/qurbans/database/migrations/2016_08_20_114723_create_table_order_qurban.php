<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableOrderQurban extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      //table field
      Schema::create('order_qurbans', function (Blueprint $table) {
          $table->increments('id');
          $table->datetime('order_date');
          $table->integer('id_donatur');
          $table->integer('id_user');
          $table->integer('id_kantor');
          $table->integer('id_kota');
          $table->text('catatan');
          $table->timestamps();
      });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
