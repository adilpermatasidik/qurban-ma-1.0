<div class="form-group">
    <label>Nama Kantor</label>
    {!! Form::text('name',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
    <label>Phone</label>
    {!! Form::text('phone',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
   <label>Email</label>
    {!! Form::input('email','email',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
   <label>Alamat</label>
    {!! Form::textarea('alamat',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
   <label>kota</label>
   {!! Form::select('id_kota',
                    $kotas,
                    null,
                    ['class'=>'form-control'])
                    !!}
</div>

{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('kantor','Kembali',['class'=>'btn btn-default']) !!}
