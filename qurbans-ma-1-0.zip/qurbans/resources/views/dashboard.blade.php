@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">
                      <div class="col-md-6">Dashboard
                        </div>
                      <div class="col-md-offset-6">
                          @if(Auth::user()->role == 'admin' or Auth::user()->role == 'fo')
                          <a href ="{{ url('donatur/create') }}" class="btn btn-success">Add Donatur &nbsp<i class="fa fa-plus"></i></a>
                          @else
                              {{ ucwords(Auth::user()->role) }}
                          @endif

                      </div>
                      </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>


            @if(Auth::user()->role == 'admin' or Auth::user()->role == 'fo')

            <!-- /.row -->
            <div class="row">

                     <!-- cari donatur -->
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Cari Donatur</div>
                     <div class="panel-body">

                       {!! Form::open(array('url'=>'donatur/search')) !!}
                               <div class="col-md-3">
                                  {!! Form::select('kantor',
                                                   $kantors,
                                                   null,
                                                   ['class'=>'form-control'])
                                                   !!}
                               </div>
                               <div class="col-md-3">
                                  {!! Form::select('field',
                                                   array('donaturs.title'=>'Title','donaturs.name'=>'Name','donaturs.phone'=>'Phone','donaturs.email'=>'Email','donaturs.alamat'=>'Alamat'),
                                                   null,
                                                   ['class'=>'form-control'])
                                                   !!}
                               </div>
                               <div class="col-md-6 input-group custom-search-form">
                                   {!! Form::text('keyword',null,['class' => 'form-control','placeholder'=>'Kata Kunci...']); !!}
                               <span class="input-group-btn">
                                   {!! Form::Submit('Cari',['class'=>'btn btn-default']) !!}
                                </div>

                       {!! Form::close() !!}



                    </div>
                </div>
            </div>
            <!-- end cari donatur -->
            @endif
            </div>

@if(Auth::user()->role == 'fo')
<!-- table data qurban -->
<!-- data jumlah hewan qurban semua pesanan -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Data Jumlah Hewan Qurban - Semua
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kantor</th>
                                <th>Kota</th>
                                <th>Dmb A</th>
                                <th>Dmb B</th>
                                <th>Sp Sup</th>
                                <th>Sp Stan</th>
                                <th>Sp RA</th>
                                <th>Sp RB</th>
                                <th>Dmb Hp</th>
                                <th>Kmbg Hp</th>
                                <th>Sp Hp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                                $no = 1;
                                $total_qmb_a = 0;
                                $total_qmb_b = 0;
                                $total_sapi_super = 0;
                                $total_sapi_standar = 0;
                                $total_sapi_r_a = 0;
                                $total_sapi_r_b = 0;
                                $total_domba_hidup = 0;
                                $total_kambing_hidup = 0;
                                $total_sapi_hidup = 0;
                          ?>
                          @foreach($qurban_by_asrama_qty as $qad)
                            <tr class="odd gradeX">
                                <td><?php echo $no; ?></td>
                                <td>{{ $qad->nama_kantor }}</td>
                                <td>{{ $qad->nama_kota }}</td>
                                <td>{{ $qad->domba_a }}</td>
                                <td>{{ $qad->domba_b }}</td>
                                <td>{{ $qad->sapi_super }}</td>
                                <td>{{ $qad->sapi_standar }}</td>
                                <td>{{ $qad->sapi_r_a }} </td>
                                <td>{{ $qad->sapi_r_b }} </td>
                                <td>{{ $qad->domba_hidup }}</td>
                                <td>{{ $qad->kambing_hidup }}</td>
                                <td>{{ $qad->sapi_hidup }}</td>
                                <td class="center">

                                </td>

                            </tr>

                            <?php
                            $total_qmb_a += $qad->domba_a;
                            $total_qmb_b += $qad->domba_b;
                            $total_sapi_super += $qad->sapi_super;
                            $total_sapi_standar += $qad->sapi_standar;
                            $total_sapi_r_a += $qad->sapi_r_a;
                            $total_sapi_r_b += $qad->sapi_r_b;
                            $total_domba_hidup += $qad->domba_hidup;
                            $total_kambing_hidup += $qad->kambing_hidup;
                            $total_sapi_hidup += $qad->sapi_hidup;
                            $no++;
                            ?>
                          @endforeach

                          <tr>
                            <th colspan="3" class="text-center">Total</th>
                            <th><?php echo $total_qmb_a; ?></th>
                            <th><?php echo $total_qmb_b; ?></th>
                            <th><?php echo $total_sapi_super; ?></th>
                            <th><?php echo $total_sapi_standar; ?></th>
                            <th><?php echo $total_sapi_r_a; ?></th>
                            <th><?php echo $total_sapi_r_b; ?></th>
                            <th><?php echo $total_domba_hidup; ?></th>
                            <th><?php echo $total_kambing_hidup; ?></th>
                            <th><?php echo $total_sapi_hidup; ?></th>
                            <th></th>
                          </tr>
                          <tr>
                            <th colspan="3" class="text-center">Grand Total</th>
                            <th colspan="10" class="text-center"><?php
                                $tgran = $total_qmb_a+$total_qmb_b+$total_sapi_super+$total_sapi_standar+$total_sapi_r_a+$total_sapi_r_b+$total_domba_hidup+$total_kambing_hidup+$total_sapi_hidup;
                                echo $tgran;
                                ?>
                            </th >
                          </tr>



                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>




<!-- table data qurban -->

<!-- table data qurban -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Nominal Hewan Qurban
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kantor</th>
                                <th>Kota</th>
                                <th>Dmb A</th>
                                <th>Dmb B</th>
                                <th>Sp Sup</th>
                                <th>Sp Stan</th>
                                <th>Sp RA</th>
                                <th>Sp RB</th>
                                <th>Dmb Hp</th>
                                <th>Kmbg Hp</th>
                                <th>Sp Hp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                                $no2 = 1;
                                $total_qmb_a2 = 0;
                                $total_qmb_b2 = 0;
                                $total_sapi_super2 = 0;
                                $total_sapi_standar2 = 0;
                                $total_sapi_r_a2 = 0;
                                $total_sapi_r_b2 = 0;
                                $total_domba_hidup2 = 0;
                                $total_kambing_hidup2 = 0;
                                $total_sapi_hidup2 = 0;
                          ?>
                          @foreach($qurban_by_asrama_nominal as $qbn)
                            <tr class="odd gradeX">
                                <td><?php echo $no; ?></td>
                                <td>{{ $qbn->nama_kantor }}</td>
                                <td>{{ $qbn->nama_kota }}</td>
                                <td>{{ format_rupiah($qbn->domba_a) }}</td>
                                <td>{{ format_rupiah($qbn->domba_b) }}</td>
                                <td>{{ format_rupiah($qbn->sapi_super) }}</td>
                                <td>{{ format_rupiah($qbn->sapi_standar) }}</td>
                                <td>{{ format_rupiah($qbn->sapi_r_a) }} </td>
                                <td>{{ format_rupiah($qbn->sapi_r_b) }} </td>
                                <td>{{ format_rupiah($qbn->domba_hidup) }}</td>
                                <td>{{ format_rupiah($qbn->kambing_hidup) }}</td>
                                <td>{{ format_rupiah($qbn->sapi_hidup) }}</td>
                                <td class="center">

                                </td>

                            </tr>

                            <?php
                            $total_qmb_a2 += $qbn->domba_a;
                            $total_qmb_b2 += $qbn->domba_b;
                            $total_sapi_super2 += $qbn->sapi_super;
                            $total_sapi_standar2 += $qbn->sapi_standar;
                            $total_sapi_r_a2 += $qbn->sapi_r_a;
                            $total_sapi_r_b2 += $qbn->sapi_r_b;
                            $total_domba_hidup2 += $qbn->domba_hidup;
                            $total_kambing_hidup2 += $qbn->kambing_hidup;
                            $total_sapi_hidup2 += $qbn->sapi_hidup;
                            $no++;
                            ?>
                          @endforeach

                          <tr>
                            <th colspan="3" class="text-center">Total</th>
                            <th><?php echo format_rupiah($total_qmb_a2); ?></th>
                            <th><?php echo format_rupiah($total_qmb_b2); ?></th>
                            <th><?php echo format_rupiah($total_sapi_super2); ?></th>
                            <th><?php echo format_rupiah($total_sapi_standar2); ?></th>
                            <th><?php echo format_rupiah($total_sapi_r_a2); ?></th>
                            <th><?php echo format_rupiah($total_sapi_r_b2); ?></th>
                            <th><?php echo format_rupiah($total_domba_hidup2); ?></th>
                            <th><?php echo format_rupiah($total_kambing_hidup2); ?></th>
                            <th><?php echo format_rupiah($total_sapi_hidup2); ?></th>
                            <th></th>
                          </tr>
                          <tr>
                            <th colspan="3" class="text-center">Grand Total</th>
                            <th colspan="10" class="text-center"><?php
                                $tgran2 = $total_qmb_a2+$total_qmb_b2+$total_sapi_super2+$total_sapi_standar2+$total_sapi_r_a2+$total_sapi_r_b2;
                                echo format_rupiah($tgran2);
                                ?>
                            </th >
                          </tr>



                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- table data qurban -->

            <!-- /.row graphic-->
<div class="row">

              <div class="col-lg-6">
                  <!-- /.panel -->
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <i class="fa fa-bar-chart-o fa-fw"></i> Jumah Hewan Qurban Har ini
                      </div>
                      <div class="panel-body">
                          <div id="grapik-qurban-by-hewan-qty"></div>

                      </div>
                      <!-- /.panel-body -->
                  </div>
                  <!-- /.panel -->
                  <!-- /.panel .chat-panel -->
              </div>
              <div class="col-lg-6">
                  <!-- /.panel -->
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <i class="fa fa-bar-chart-o fa-fw"></i> Pendapatan Qurban hari ini
                      </div>
                      <div class="panel-body">

                          <div id="grapik-qurban-by-hewan-nominal"></div>
                      </div>
                      <!-- /.panel-body -->
                  </div>
                  <!-- /.panel -->
                  <!-- /.panel .chat-panel -->
              </div>

                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Grapik Jumlah Qurban

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="grapik-qurban-by-tanggal-qty"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Grapik Pendapatan Qurban

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="grapik-qurban-by-tanggal-nominal"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                </div>
                <!-- /.col-lg-8 -->

                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row graphic-->
@endif
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script>
    $(function() {

        Morris.Line({
            element: 'grapik-qurban-by-tanggal-qty',
            data: [
            @foreach($qurban_by_date_qty as $qdtq)
              {

                date: '{{ $qdtq->date }}',
                qurban: {{ $qdtq->qty }}
              },
            @endforeach
            ],
            xkey: 'date',
            ykeys: ['qurban'],
            labels: ['qurban'],
            pointSize: 2,
            hideHover: 'auto',
            resize: true
        });

        Morris.Line({
            element: 'grapik-qurban-by-tanggal-nominal',
            data: [
            @foreach($qurban_by_date_nominal as $qdtn)
              {

                date: '{{ $qdtn->date }}',
                qurban: {{ $qdtn->harga }}
              },
            @endforeach
            ],
            xkey: 'date',
            ykeys: ['qurban'],
            labels: ['qurban'],
            pointSize: 2,
            hideHover: 'auto',
            resize: true
        });

        Morris.Donut({
            element: 'grapik-qurban-by-hewan-qty',
            data: [
              @foreach($qurban_to_day_qty as $qdq)
              {
                label: '{{ $qdq->nama_hewan }}',
                value: {{ $qdq->qty }}
              },
              @endforeach
                  ],
            resize: true
        });

        Morris.Donut({
            element: 'grapik-qurban-by-hewan-nominal',
            data: [
              @foreach($qurban_to_day_nominal as $qdn)
              {
                label: '{{ $qdn->nama_hewan }}',
                value: {{ $qdn->harga }}
              },
              @endforeach
                  ],
            resize: true
        });

    });

    </script>

@stop
