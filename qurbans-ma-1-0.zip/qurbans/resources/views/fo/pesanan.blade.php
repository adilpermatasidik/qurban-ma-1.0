@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">
                      Laporan Jumlah Hewan Qurban by Pesanan
                </div>
                <!-- /.col-lg-12 -->
            </div>





<!-- table data qurban -->
<!-- data jumlah hewan qurban semua pesanan -->


<!-- data jumlah hewan qurban disaksikan -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-red">
            <div class="panel-heading">
                Data Jumlah Hewan Qurban - Disaksikan
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kantor</th>
                                <th>Kota</th>
                                <th>Dmb A</th>
                                <th>Dmb B</th>
                                <th>Sp Sup</th>
                                <th>Sp Stan</th>
                                <th>Sp RA</th>
                                <th>Sp RB</th>
                                <th>Dmb Hp</th>
                                <th>Kmbg Hp</th>
                                <th>Sp Hp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                                $no = 1;
                                $total_qmb_ads = 0;
                                $total_qmb_bds = 0;
                                $total_sapi_superds = 0;
                                $total_sapi_standards = 0;
                                $total_sapi_r_ads = 0;
                                $total_sapi_r_bds = 0;
                                $total_domba_hidupds = 0;
                                $total_kambing_hidupds = 0;
                                $total_sapi_hidupds = 0;
                          ?>
                          @foreach($qurban_asrama_disaksikan as $qads)
                            <tr class="odd gradeX">
                                <td><?php echo $no; ?></td>
                                <td>{{ $qads->nama_kantor }}</td>
                                <td>{{ $qads->nama_kota }}</td>
                                <td>{{ $qads->domba_a }}</td>
                                <td>{{ $qads->domba_b }}</td>
                                <td>{{ $qads->sapi_super }}</td>
                                <td>{{ $qads->sapi_standar }}</td>
                                <td>{{ $qads->sapi_r_a }} </td>
                                <td>{{ $qads->sapi_r_b }} </td>
                                <td>{{ $qads->domba_hidup }}</td>
                                <td>{{ $qads->kambing_hidup }}</td>
                                <td>{{ $qads->sapi_hidup }}</td>
                                <td class="center">
				 <a href ="{{ url('distribusi/detail').'/'.$qads->kantor_id.'/2?hal=fo-pesanan' }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>

                                </td>

                            </tr>

                            <?php
                            $total_qmb_ads += $qads->domba_a;
                            $total_qmb_bds += $qads->domba_b;
                            $total_sapi_superds += $qads->sapi_super;
                            $total_sapi_standards += $qads->sapi_standar;
                            $total_sapi_r_ads += $qads->sapi_r_a;
                            $total_sapi_r_bds += $qads->sapi_r_b;
                            $total_domba_hidupds += $qads->domba_hidup;
                            $total_kambing_hidupds += $qads->kambing_hidup;
                            $total_sapi_hidupds += $qads->sapi_hidup;
                            $no++;
                            ?>
                          @endforeach

                          <tr>
                            <th colspan="3" class="text-center">Total</th>
                            <th><?php echo $total_qmb_ads; ?></th>
                            <th><?php echo $total_qmb_bds; ?></th>
                            <th><?php echo $total_sapi_superds; ?></th>
                            <th><?php echo $total_sapi_standards; ?></th>
                            <th><?php echo $total_sapi_r_ads; ?></th>
                            <th><?php echo $total_sapi_r_bds; ?></th>
                            <th><?php echo $total_domba_hidupds; ?></th>
                            <th><?php echo $total_kambing_hidupds; ?></th>
                            <th><?php echo $total_sapi_hidupds; ?></th>
                            <th></th>
                          </tr>
                          <tr>
                            <th colspan="3" class="text-center">Grand Total</th>
                            <th colspan="10" class="text-center"><?php
                                $tgrands = $total_qmb_ads+$total_qmb_bds+$total_sapi_superds+$total_sapi_standards+$total_sapi_r_ads+$total_sapi_r_bds+$total_domba_hidupds+$total_kambing_hidupds+$total_sapi_hidupds;
                                echo $tgrands;
                                ?>
                            </th >
                          </tr>



                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- table data qurban -->

<!-- data jumlah hewan qurban dokumentasi -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                Data Jumlah Hewan Qurban - Dokumentasi
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kantor</th>
                                <th>Kota</th>
                                <th>Dmb A</th>
                                <th>Dmb B</th>
                                <th>Sp Sup</th>
                                <th>Sp Stan</th>
                                <th>Sp RA</th>
                                <th>Sp RB</th>
                                <th>Dmb Hp</th>
                                <th>Kmbg Hp</th>
                                <th>Sp Hp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                                $no = 1;
                                $total_qmb_add = 0;
                                $total_qmb_bdd = 0;
                                $total_sapi_superdd = 0;
                                $total_sapi_standardd = 0;
                                $total_sapi_r_add = 0;
                                $total_sapi_r_bdd = 0;
                                $total_domba_hidupdd = 0;
                                $total_kambing_hidupdd = 0;
                                $total_sapi_hidupdd = 0;
                          ?>
                          @foreach($qurban_asrama_dokumentasi as $qadd)
                            <tr class="odd gradeX">
                                <td><?php echo $no; ?></td>
                                <td>{{ $qadd->nama_kantor }}</td>
                                <td>{{ $qadd->nama_kota }}</td>
                                <td>{{ $qadd->domba_a }}</td>
                                <td>{{ $qadd->domba_b }}</td>
                                <td>{{ $qadd->sapi_super }}</td>
                                <td>{{ $qadd->sapi_standar }}</td>
                                <td>{{ $qadd->sapi_r_a }} </td>
                                <td>{{ $qadd->sapi_r_b }} </td>
                                <td>{{ $qadd->domba_hidup }}</td>
                                <td>{{ $qadd->kambing_hidup }}</td>
                                <td>{{ $qadd->sapi_hidup }}</td>
                                <td class="center">
                                  <a href ="{{ url('distribusi/detail').'/'.$qadd->kantor_id.'/4?hal=fo-pesanan' }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>

                                </td>

                            </tr>

                            <?php
                            $total_qmb_add += $qadd->domba_a;
                            $total_qmb_bdd += $qadd->domba_b;
                            $total_sapi_superdd += $qadd->sapi_super;
                            $total_sapi_standardd += $qadd->sapi_standar;
                            $total_sapi_r_add += $qadd->sapi_r_a;
                            $total_sapi_r_bdd += $qadd->sapi_r_b;
                            $total_domba_hidupdd += $qadd->domba_hidup;
                            $total_kambing_hidupdd += $qadd->kambing_hidup;
                            $total_sapi_hidupdd += $qadd->sapi_hidup;
                            $no++;
                            ?>
                          @endforeach

                          <tr>
                            <th colspan="3" class="text-center">Total</th>
                            <th><?php echo $total_qmb_add; ?></th>
                            <th><?php echo $total_qmb_bdd; ?></th>
                            <th><?php echo $total_sapi_superdd; ?></th>
                            <th><?php echo $total_sapi_standardd; ?></th>
                            <th><?php echo $total_sapi_r_add; ?></th>
                            <th><?php echo $total_sapi_r_bdd; ?></th>
                            <th><?php echo $total_domba_hidupdd; ?></th>
                            <th><?php echo $total_kambing_hidupdd; ?></th>
                            <th><?php echo $total_sapi_hidupdd; ?></th>
                            <th></th>
                          </tr>
                          <tr>
                            <th colspan="3" class="text-center">Grand Total</th>
                            <th colspan="10" class="text-center"><?php
                                $tgrandd = $total_qmb_add+$total_qmb_bdd+$total_sapi_superdd+$total_sapi_standardd+$total_sapi_r_add+$total_sapi_r_bdd+$total_domba_hidupdd+$total_kambing_hidupdd+$total_sapi_hidupdd;
                                echo $tgrandd;
                                ?>
                            </th >
                          </tr>



                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<!-- data jumlah hewan qurban bebas -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-green">
            <div class="panel-heading">
                Data Jumlah Hewan Qurban - Bebas
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kantor</th>
                                <th>Kota</th>
                                <th>Dmb A</th>
                                <th>Dmb B</th>
                                <th>Sp Sup</th>
                                <th>Sp Stan</th>
                                <th>Sp RA</th>
                                <th>Sp RB</th>
                                <th>Dmb Hp</th>
                                <th>Kmbg Hp</th>
                                <th>Sp Hp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                                $no = 1;
                                $total_qmb_adbs = 0;
                                $total_qmb_bdbs = 0;
                                $total_sapi_superdbs = 0;
                                $total_sapi_standardbs = 0;
                                $total_sapi_r_adbs = 0;
                                $total_sapi_r_bdbs = 0;
                                $total_domba_hidupdbs = 0;
                                $total_kambing_hidupdbs = 0;
                                $total_sapi_hidupdbs = 0;
                          ?>
                          @foreach($qurban_asrama_bebas as $qadbs)
                            <tr class="odd gradeX">
                                <td><?php echo $no; ?></td>
                                <td>{{ $qadbs->nama_kantor }}</td>
                                <td>{{ $qadbs->nama_kota }}</td>
                                <td>{{ $qadbs->domba_a }}</td>
                                <td>{{ $qadbs->domba_b }}</td>
                                <td>{{ $qadbs->sapi_super }}</td>
                                <td>{{ $qadbs->sapi_standar }}</td>
                                <td>{{ $qadbs->sapi_r_a }} </td>
                                <td>{{ $qadbs->sapi_r_b }} </td>
                                <td>{{ $qadbs->domba_hidup }}</td>
                                <td>{{ $qadbs->kambing_hidup }}</td>
                                <td>{{ $qadbs->sapi_hidup }}</td>
                                <td class="center">
                                 <a href ="{{ url('distribusi/detail').'/'.$qadbs->kantor_id.'/5?hal=fo-pesanan' }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>

                                </td>

                            </tr>

                            <?php
                            $total_qmb_adbs += $qadbs->domba_a;
                            $total_qmb_bdbs += $qadbs->domba_b;
                            $total_sapi_superdbs += $qadbs->sapi_super;
                            $total_sapi_standardbs += $qadbs->sapi_standar;
                            $total_sapi_r_adbs += $qadbs->sapi_r_a;
                            $total_sapi_r_bdbs += $qadbs->sapi_r_b;
                            $total_domba_hidupdbs += $qadbs->domba_hidup;
                            $total_kambing_hidupdbs += $qadbs->kambing_hidup;
                            $total_sapi_hidupdbs += $qadbs->sapi_hidup;
                            $no++;
                            ?>
                          @endforeach

                          <tr>
                            <th colspan="3" class="text-center">Total</th>
                            <th><?php echo $total_qmb_adbs; ?></th>
                            <th><?php echo $total_qmb_bdbs; ?></th>
                            <th><?php echo $total_sapi_superdbs; ?></th>
                            <th><?php echo $total_sapi_standardbs; ?></th>
                            <th><?php echo $total_sapi_r_adbs; ?></th>
                            <th><?php echo $total_sapi_r_bdbs; ?></th>
                            <th><?php echo $total_domba_hidupdbs; ?></th>
                            <th><?php echo $total_kambing_hidupdbs; ?></th>
                            <th><?php echo $total_sapi_hidupdbs; ?></th>
                            <th></th>
                          </tr>
                          <tr>
                            <th colspan="3" class="text-center">Grand Total</th>
                            <th colspan="10" class="text-center"><?php
                                $tgrandbs = $total_qmb_adbs+$total_qmb_bdbs+$total_sapi_superdbs+$total_sapi_standardbs+$total_sapi_r_adbs+$total_sapi_r_bdbs+$total_domba_hidupdbs+$total_kambing_hidupdbs+$total_sapi_hidupdbs;
                                echo $tgrandbs;
                                ?>
                            </th >
                          </tr>



                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


<!-- table data qurban -->


@stop
