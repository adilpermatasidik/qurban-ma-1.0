<!-- jumlah hewan qurban -->
@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">
                      <div class="col-md-8">Grapik Qurban by Pembayaran | {{ $text }}</div>
                      <div class="col-md-offset-4">
                          <a href ="{{ url('laporan/payment/qty') }}" class="btn btn-default">Kuantitas &nbsp;<i class="fa fa-shopping-cart"></i></a>
                          <a href ="{{ url('laporan/payment/nominal') }}" class="btn btn-default">Nominal &nbsp;<i class="fa fa-dollar"></i></a>
                      </div>
                      </h1>
                <!-- /.col-lg-12 -->
            </div>

            <!-- /.row -->
            <div class="row">

                <!-- /.col-lg-8 -->
                <div class="col-lg-12">
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Donasi by Pembayaran
                        </div>
                        <div class="panel-body">
                            <div id="donasi-by-pembayaran"></div>
                            <a href="#" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script type="text/javascript">
    $(function() {

      Morris.Bar({
         element: 'donasi-by-pembayaran',
         data: [
         @if($jenis=='qty')
         @foreach($qurban_by_payment as $qbp)

           {
             y: '{{ $qbp->payment }}',
             a: {{ $qbp->qty }}
           },

         @endforeach
         @endif

         @if($jenis=='nominal')
         @foreach($qurban_by_payment as $qbp)

           {
             y: '{{ $qbp->payment }}',
             a: {{ $qbp->harga }}
           },

         @endforeach
         @endif

         ],
         xkey: 'y',
         ykeys: ['a'],
         labels: ['Donasi'],
         hideHover: 'auto',
         resize: true
     });

});
    </script>

@stop
