@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Grapik Donasi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>


            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Grapik Donasi Qurban
                            <div class="pull-right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                        Filter
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu pull-right" role="menu">
                                        <li><a href="#">Hari</a>
                                        </li>
                                        <li><a href="#">Minggu</a>
                                        </li>
                                        <li><a href="#">Bulan</a>
                                        </li>
                                        <li><a href="#">Tahun</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="grapik-qurban-by-tanggal"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script>
    $(function() {

        Morris.Line({
            element: 'grapik-qurban-by-tanggal',
            data: [
            @foreach($qurban_by_date as $qbd)
              {

                date: '{{ $qbd->date }}',
                qurban: {{ $qbd->qty }}

              },
            @endforeach
            ],
            xkey: 'date',
            ykeys: ['qurban','nominal'],
            labels: ['qurban','nominal'],
            pointSize: 2,
            hideHover: 'auto',
            resize: true
        });

    });

    </script>

@stop
