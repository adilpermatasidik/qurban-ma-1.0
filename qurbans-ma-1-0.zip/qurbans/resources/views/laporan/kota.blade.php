<!-- jumlah hewan qurban -->
@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Donasi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

            <!-- /.row -->
            <div class="row">
            
                <!-- /.col-lg-8 -->
                <div class="col-lg-12">
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Transaksi by Kota
                        </div>
                        <div class="panel-body">
                            <div id="transaksi-by-kota"></div>
                            <a href="#" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script type="text/javascript">
    $(function() {

    Morris.Donut({
        element: 'transaksi-by-kota',
        data: [{
            label: "Jakarta",
            value: 100
        }, {
            label: "Bandung",
            value: 50
        }, {
            label: "Surabaya",
            value: 10
        },{
            label: "Semarang",
            value: 5
        },],
        resize: true
    });
    
});
    </script>
    
@stop
