<!-- jumlah hewan qurban -->
@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Distribusi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

            <!-- /.row -->
            <div class="row">
            
                <!-- /.col-lg-8 -->
                <div class="col-lg-12">
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Data Distribusi Kambing
                        </div>
                        <div class="panel-body">
                            <div id="data-distribusi"></div>
                          
                            <a href="#" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                     <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Data Distribusi Sapi
                        </div>
                        <div class="panel-body">
                          
                            <div id="data-distribusi-kambing"></div>
                            <a href="#" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script type="text/javascript">
    $(function() {

    Morris.Donut({
        element: 'data-distribusi',
        data: [{
            label: "Cinere",
            value: 60
        }, {
            label: "Cipete",
            value: 40
        }, {
            label: "Klender",
            value: 10
        },{
            label: "Free",
            value: 15
        },],
        resize: true
    });

    Morris.Donut({
        element: 'data-distribusi-kambing',
        data: [{
            label: "Cinere",
            value: 60
        }, {
            label: "Cipete",
            value: 40
        }, {
            label: "Klender",
            value: 10
        },{
            label: "Free",
            value: 15
        },],
        resize: true
    });
    
});
    </script>
    
@stop