<!-- jumlah hewan qurban -->
@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Hewan Qurban</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

            <!-- /.row -->
            <div class="row">

                <!-- /.col-lg-8 -->
                <div class="col-lg-12">
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Jumlah Hewan Qurban
                        </div>
                        <div class="panel-body">
                            <div id="grapik-qurban-by-hewan"></div>
                          
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Jumlah Hewan Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kantor</th>
                                            <th>Kota</th>
                                            <th>Dmb A</th>
                                            <th>Dmb B</th>
                                            <th>Sp Sup</th>
                                            <th>Sp Stan</th>
                                            <th>Sp RA</th>
                                            <th>Sp RB</th>
                                            <th>Dmb Hp</th>
                                            <th>Kmbg Hp</th>
                                            <th>Sp Hp</th>
                                            <!--<th>Action</th>-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php
                                            $no = 1;
                                            $total_qmb_a = 0;
                                            $total_qmb_b = 0;
                                            $total_sapi_super = 0;
                                            $total_sapi_standar = 0;
                                            $total_sapi_r_a = 0;
                                            $total_sapi_r_b = 0;
                                            $total_domba_hidup = 0;
                                            $total_kambing_hidup = 0;
                                            $total_sapi_hidup = 0;
                                      ?>
                                      @foreach($qurban_asrama_disaksikan as $qad)
                                        <tr class="odd gradeX">
                                            <td><?php echo $no; ?></td>
                                            <td>{{ $qad->nama_kantor }}</td>
                                            <td>{{ $qad->nama_kota }}</td>
                                            <td>{{ $qad->domba_a }}</td>
                                            <td>{{ $qad->domba_b }}</td>
                                            <td>{{ $qad->sapi_super }}</td>
                                            <td>{{ $qad->sapi_standar }}</td>
                                            <td>{{ $qad->sapi_r_a }} </td>
                                            <td>{{ $qad->sapi_r_b }} </td>
                                            <td>{{ $qad->domba_hidup }}</td>
                                            <td>{{ $qad->kambing_hidup }}</td>
                                            <td>{{ $qad->sapi_hidup }}</td>
                                            <!--<td class="center">
                                                <!--<a href ="{{ url('distribusi/detail').'/'.$qad->kantor_id.'/'.$pesanan_id }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>
                                            </td>-->

                                        </tr>

                                        <?php
                                        $total_qmb_a += $qad->domba_a;
                                        $total_qmb_b += $qad->domba_b;
                                        $total_sapi_super += $qad->sapi_super;
                                        $total_sapi_standar += $qad->sapi_standar;
                                        $total_sapi_r_a += $qad->sapi_r_a;
                                        $total_sapi_r_b += $qad->sapi_r_b;
                                        $total_domba_hidup += $qad->domba_hidup;
                                        $total_kambing_hidup += $qad->kambing_hidup;
                                        $total_sapi_hidup += $qad->sapi_hidup;
                                        $no++;
                                        ?>
                                      @endforeach

                                      <tr>
                                        <th colspan="3" class="text-center">Total</th>
                                        <th><?php echo $total_qmb_a; ?></th>
                                        <th><?php echo $total_qmb_b; ?></th>
                                        <th><?php echo $total_sapi_super; ?></th>
                                        <th><?php echo $total_sapi_standar; ?></th>
                                        <th><?php echo $total_sapi_r_a; ?></th>
                                        <th><?php echo $total_sapi_r_b; ?></th>
                                        <th><?php echo $total_domba_hidup; ?></th>
                                        <th><?php echo $total_kambing_hidup; ?></th>
                                        <th><?php echo $total_sapi_hidup; ?></th>

                                      </tr>
                                      <tr>
                                        <th colspan="3" class="text-center">Grand Total</th>
                                        <th colspan="9" class="text-center"><?php
                                            $tgran = $total_qmb_a+$total_qmb_b+$total_sapi_super+$total_sapi_standar+$total_sapi_r_a+$total_sapi_r_b+$total_domba_hidup+$total_kambing_hidup+$total_sapi_hidup;
                                            echo $tgran;
                                            ?>
                                        </th >
                                      </tr>



                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>

          <!-- Morris Charts JavaScript -->
    <script src="{{ asset('bower_components/raphael/raphael-min.js') }}"></script>
    <script src="{{ asset('bower_components/morrisjs/morris.min.js') }}"></script>
    <script>
    $(function() {

        Morris.Donut({
            element: 'grapik-qurban-by-hewan',
            data: [
              @foreach($qurban_by_hewan as $qbh)
              {
                label: '{{ $qbh->nama_hewan }}',
                value: {{ $qbh->qty }}
              },
              @endforeach
                  ],
            resize: true
        });

    });

    </script>

@stop
