<div class="form-group">
    <label>Nama Pesanan</label>
    {!! Form::text('name',null,['class'=>'form-control']) !!}
    <p class="help-block">Wajib Isi</p>
</div>
{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('pembayaran','Kembali',['class'=>'btn btn-default']) !!}
