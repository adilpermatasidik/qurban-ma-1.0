@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Pembayaran</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Pembayaran
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <div class="col-lg-12">
                                  @if((Html::ul($errors->all())))
                                  <div class="alert alert-danger">
                                      {!! Html::ul($errors->all()) !!}
                                  </div>
                                  @endif

                                  {!! Form::model($pembayaran,array('url'=>'pembayaran/'.$pembayaran->id,'method'=>'patch')) !!}

                                      @include('pembayaran.form')

                                  {!! Form::close(); !!}
                                </div>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop
