<div class="form-group">
    <label>Title</label>
    {!! Form::select('title',
                     array('Bapak'=>'Bapak','Ibu'=>'Ibu'),
                     null,
                     ['class'=>'form-control'])
                     !!}
</div>

<div class="form-group">
    <label>Nama Donatur</label>
    {!! Form::text('name',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
    <label>Phone</label>
    {!! Form::input('number','phone',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
   <label>Email</label>
    {!! Form::input('email','email',null,['class'=>'form-control']) !!}
</div>

<div class="form-group">
   <label>Alamat</label>
    {!! Form::textarea('alamat',null,['class'=>'form-control']) !!}
</div>

{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('donatur','Kembali',['class'=>'btn btn-default']) !!}
