  @extends('template.master')
  @section('content')
  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        <div class="col-md-6">Data Donatur</div>
                        <div class="col-md-offset-6">
                            <a href ="{{ url('donatur/create') }}" class="btn btn-success">Add Donatur &nbsp<i class="fa fa-plus"></i></a>
                            <a href ="{{ url('donatur') }}" class="btn btn-default">Refresh &nbsp<i class="fa fa-refresh"></i></a>

                        </div>
                        </h1>

                </div>

                <!-- /.col-lg-12 -->
            </div>

            <!-- cari donatur -->
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Cari Data donatur</div>
                     <div class="panel-body">
                        {!! Form::open(array('url'=>'donatur/search')) !!}
                                <div class="col-md-3">
                                   {!! Form::select('kantor',
                                                    $kantors,
                                                    null,
                                                    ['class'=>'form-control'])
                                                    !!}
                                </div>
                                <div class="col-md-3">
                                   {!! Form::select('field',
                                                    array('donaturs.title'=>'Title','donaturs.name'=>'Name','donaturs.phone'=>'Phone','donaturs.email'=>'Email','donaturs.alamat'=>'Alamat'),
                                                    null,
                                                    ['class'=>'form-control'])
                                                    !!}
                                </div>
                                <div class="col-md-6 input-group custom-search-form">
                                    {!! Form::text('keyword',null,['class' => 'form-control','placeholder'=>'Kata Kunci...']); !!}
                                <span class="input-group-btn">
                                    {!! Form::Submit('Cari',['class'=>'btn btn-default']) !!}
                                 </div>

                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
            <!-- end cari donatur -->

            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Table Donatur
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Telepon</th>
                                            <th>Email</th>
                                            <th>Alamat</th>
                                            <th>user</th>
                                            <th>Kantor</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                      <?php
                                      if(isset($_GET['page'])){
                                      $no = ($_GET['page'] - 1) * $limit;
                                      $nom = $no+1;
                                      }else
                                      {
                                          $nom = 1;
                                      }
                                      ?>

                                        @foreach($donaturs as $donatur)
                                        <tr class="odd gradeX">
                                          <td><?php echo $nom; ?></td>
                                          <td>
                                            @if(Auth::user()->role == 'fo' or Auth::user()->role == 'admin')
                                            <a href="{{ url('qurban/addItem')."/".$donatur->id }}"> {{ $donatur->title." ".$donatur->name }} </a>
                                          @else
                                            {{ $donatur->title." ".$donatur->name }} 
                                          @endif
                                          </td>
                                          <td>{{ $donatur->phone }}</td>
                                          <td>{{ $donatur->email }}</td>
                                          <td>{{ $donatur->alamat }}</td>
                                          <td>{{ $donatur->username }}</td>
                                          <td>{{ $donatur->kantor }}</td>
                                          <td>
                                            <?php if(Auth::user()->role == 'fo' or Auth::user()->role == 'admin'){ ?>
                                            <a href ="{{ url('qurban/addItem')."/".$donatur->id }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Donasi Qurban"><i class="fa fa-shopping-cart"></i></a>
                                            <?php } ?>
                                            <a href ="{{ url('donatur').'/'.$donatur->id }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>
                                            <?php if($donatur->user_id == Auth::user()->id or Auth::user()->role == 'admin'){ ?>
                                            <a href ="{{ url('donatur').'/'.$donatur->id.'/'.'edit' }}" class="btn btn-success btn-circle" data-toggle="tooltip" data-placement="bottom" title="Edit"><i class="fa fa-pencil"></i></a>
                                            <?php } ?>
                                            <?php if(Auth::user()->role == 'admin'){ ?>
                                            <a onclick="return confirm('Apakah anda ingin menghapus data ini?')" href ="{{ url('donatur/destroy').'/'.$donatur->id }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                            <?php } ?>
                                          </td>
                                        </tr>
                                        <?php $nom++; ?>
                                      @endforeach

                                    </tbody>
                                </table>
                                {!! $donaturs->render(); !!}

                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <!-- /#page-wrapper -->

      <!-- Page-Level Demo Scripts - Tables - Use for reference -->

    <script>
    // tooltip demo
    $('.dataTable_wrapper').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>

    @stop
