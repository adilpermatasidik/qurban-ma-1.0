@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Detail Donatur</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Donatur
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <div class="col-lg-12">

                                  <div class="form-group">
                                      <label>Nama Donatur</label>
                                      <p><a href="{{ url('qurban/addItem/').$donaturs->id }}"> {{ $donaturs->title." ".$donaturs->name }} </a></p>
                                  </div>

                                  <div class="form-group">
                                      <label>Phone</label>
                                      <p>{{ $donaturs->phone }}</p>
                                  </div>

                                  <div class="form-group">
                                     <label>Email</label>
                                      <p>{{ $donaturs->email }}</p>
                                  </div>

                                  <div class="form-group">
                                     <label>Alamat</label>
                                      <p>{{ $donaturs->alamat }}</p>
                                  </div>




                                  {!! link_to('qurban/addItem/'.$donaturs->id,'Buat Donasi Qurban',['class'=>'btn btn-success']) !!}
                                  {!! link_to('donatur','Kembali',['class'=>'btn btn-default']) !!}



                                </div>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop
