@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">

                      <div class="col-md-6">{{$text}} {{ $detailDist[0]->kantor }}</div>

                      <div class="col-md-offset-6">

                          <a href ="{{ url($kembali) }}" class="btn btn-default">Kembali &nbsp;<i class="fa fa-undo"></i></a>
                          <a href ="{{ url($excel) }}" class="btn btn-default"> Export Excel &nbsp;<i class="fa fa-file-excel-o"></i></a>

                      </div>
                      </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Distribusi Hewan Qurban yang {{$text}}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>No Kwitansi</th>
                                            <th>Jenis Hewan</th>
                                            <th>Qty</th>
                                            <th>Harga</th>
                                            <th>Pequrban</th>
                                            <th>Pesanan Khusus</th>
                                            <th>Pembayaran</th>
                                            <th>Asrama</th>
                                            <th>konversi</th>
                                            <th>Catatan</th>
                                            <!--<th>Acion</th>-->

                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php
                                      if(isset($_GET['page'])){
                                      $no = ($_GET['page'] - 1) * $limit;
                                      $nom = $no+1;
                                      }else
                                      {
                                          $nom = 1;
                                      }
                                      ?>

                                      @foreach($detailDist as $dd)
                                        <tr>
                                            <td><?php echo $nom; ?></td>
                                            <td>{{$dd->kwitansi_id}}</td>
                                            <td>{{$dd->jenis_hewan}}</td>
                                            <td>{{$dd->qty}}</td>
                                            <td>{{format_rupiah($dd->harga)}}</td>
                                            <td>{{$dd->pequrban}}</td>
                                            <td>{{$dd->pesanan}}</td>
                                            <td>{{$dd->pembayaran}}</td>
                                            <td>{{$dd->kantor}}</td>
                                            <td>{{$dd->konv}}</td>
                                            <td>{{$dd->catatan}}</td>
                                            <!--<td class="center">
                                                <a href ="{{ url('distribusi/detail/form') }}" class="btn btn-default btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Ubah Distribusi"><i class="fa fa-pencil"></i></a>
                                            </td>-->
                                        </tr>
                                        <?php $nom++; ?>
                                      @endforeach


                                    </tbody>
                                </table>
                                <!--<button type="submit" class="btn btn-default">Simpan</button>-->
                                <!--<button type="reset" class="btn btn-default">Batal</button>-->
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

        @stop
