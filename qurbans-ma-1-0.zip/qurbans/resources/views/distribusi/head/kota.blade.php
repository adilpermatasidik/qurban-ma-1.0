@extends('template.master')
@section('content')
<div id="page-wrapper">
          <div class="row">
              <div class="col-lg-12">
                  <h1 class="page-header">
                      <div class="col-md-6">Lokasi Distribusi {{$text}}</div>
                      <div class="col-md-offset-6">
                          <a href ="#" class="btn btn-success btn-circle"><i class="fa fa-plus"></i></a>
                      </div>
                      </h1>

              </div>

              <!-- /.col-lg-12 -->
          </div>
          <!-- /.row -->
          <div class="row">
              <div class="col-lg-12">
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          Data Lokasi Distribusi Qurban - Data Qurban yang {{$text}}
                      </div>
                      <!-- /.panel-heading -->
                      <div class="panel-body">
                          <div class="dataTable_wrapper">
                              <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                  <thead>
                                      <tr>
                                          <th>No</th>
                                          <th>Kota</th>
                                          <th>Dmb A</th>
                                          <th>Dmb B</th>
                                          <th>Sp Sup</th>
                                          <th>Sp Stan</th>
                                          <th>Sp RA</th>
                                          <th>Sp RB</th>
                                          <th>Dmb Hp</th>
                                          <th>Kmbg Hp</th>
                                          <th>Sp Hp</th>
                                          <!--<th>Action</th>-->
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php $no = 1; 
                                    	    $total_qmb_a = 0;
                                	    $total_qmb_b = 0;
		                            $total_sapi_super = 0;
		                            $total_sapi_standar = 0;
		                            $total_sapi_r_a = 0;
		                            $total_sapi_r_b = 0;
		                            $total_domba_hidup = 0;
		                            $total_kambing_hidup = 0;
		                            $total_sapi_hidup = 0;
                                    ?>
                                    @foreach($qurban_asrama_disaksikan as $qad)
                                      <tr class="odd gradeX">
                                          <td><?php echo $no; ?></td>
                                          <td>{{ $qad->nama_kota }}</td>
                                          <td>{{ $qad->domba_a }}</td>
                                          <td>{{ $qad->domba_b }}</td>
                                          <td>{{ $qad->sapi_super }}</td>
                                          <td>{{ $qad->sapi_standar }}</td>
                                          <td>{{ $qad->sapi_r_a }} ({{ $qad->sapi_r_a/7 }})</td>
                                          <td>{{ $qad->sapi_r_b }} ({{ $qad->sapi_r_b/7 }})</td>
                                          <td>{{ $qad->domba_hidup }}</td>
                                          <td>{{ $qad->kambing_hidup }}</td>
                                          <td>{{ $qad->sapi_hidup }}</td>
                                          <!--<td class="center">
                                              <a href ="{{ url('distribusi/detail/index') }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>
                                          </td>-->
                                      </tr>
                                      <?php $no++;  
                                      $total_qmb_a += $qad->domba_a;
                            		$total_qmb_b += $qad->domba_b;
                            		$total_sapi_super += $qad->sapi_super;
		                        $total_sapi_standar += $qad->sapi_standar;
		                        $total_sapi_r_a += $qad->sapi_r_a;
		                        $total_sapi_r_b += $qad->sapi_r_b;
		                        $total_domba_hidup += $qad->domba_hidup;
		                        $total_kambing_hidup += $qad->kambing_hidup;
		                        $total_sapi_hidup += $qad->sapi_hidup;
                                      ?>
                                    @endforeach
			  <tr>
                            <th colspan="2" class="text-center">Total</th>
                            <th><?php echo $total_qmb_a; ?></th>
                            <th><?php echo $total_qmb_b; ?></th>
                            <th><?php echo $total_sapi_super; ?></th>
                            <th><?php echo $total_sapi_standar; ?></th>
                            <th><?php echo $total_sapi_r_a; ?></th>
                            <th><?php echo $total_sapi_r_b; ?></th>
                            <th><?php echo $total_domba_hidup; ?></th>
                            <th><?php echo $total_kambing_hidup; ?></th>
                            <th><?php echo $total_sapi_hidup; ?></th>
                            
                          </tr>
                          <tr>
                            <th colspan="2" class="text-center">Grand Total</th>
                            <th colspan="9" class="text-center"><?php
                                $tgran = $total_qmb_a+$total_qmb_b+$total_sapi_super+$total_sapi_standar+$total_sapi_r_a+$total_sapi_r_b+$total_domba_hidup+$total_kambing_hidup+$total_sapi_hidup;
                                echo $tgran;
                                ?>
                            </th >
                          </tr>


                                  </tbody>
                              </table>
                          </div>
                          <!-- /.table-responsive -->
                      </div>
                      <!-- /.panel-body -->
                  </div>
                  <!-- /.panel -->
              </div>
              <!-- /.col-lg-12 -->
          </div>
      </div>
      <!-- /#page-wrapper -->

      <!-- DataTables JavaScript -->
  <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
  <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
  <script src="../bower_components/datatables-responsive/js/dataTables.responsive.js"></script>
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
  <script>
  $(document).ready(function() {
      $('#dataTables-example').DataTable({
              responsive: true
      });
  });
  </script>

  <script>
  // tooltip demo
  $('.dataTable_wrapper').tooltip({
      selector: "[data-toggle=tooltip]",
      container: "body"
  })

  // popover demo
  $("[data-toggle=popover]")
      .popover()
  </script>

  @stop
