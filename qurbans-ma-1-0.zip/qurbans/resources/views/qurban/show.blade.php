@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">

                <div class="col-lg-12">
                  <h1 class="page-header">
                  <div class="col-md-6">Detail Donasi Qurban</div>
                  <div class="col-md-offset-6">
                      <a href ="{{ url('qurban') }}" class="btn btn-default btn-circle" data-toggle="tooltip" title="Refresh"><i class="fa fa-repeat"></i></a>
                  </div>
                  </h1>
                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                @foreach($qurbans as $qurban)
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Donatur Qurban
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">



                                  <div class="form-group">
                                      <label>Nama Donatur</label>
                                      <p> {{ $qurban->title." ".$qurban->nama_donatur }} </p>
                                  </div>

                                  <div class="form-group">
                                      <label>Phone</label>
                                      <p>{{ $qurban->phone }}</p>
                                  </div>

                                  <div class="form-group">
                                      <label>Email</label>
                                      <p>{{ $qurban->email }}</p>
                                  </div>

                                  <div class="form-group">
                                        <label>Alamat</label>
                                      <p>{{ $qurban->alamat }}</p>
                                  </div>


                                </div>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

<!-- form aplikasi qurban -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Transaksi Qurban
                        </div>
                        <!-- /.panel-heading -->

                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">

                                        <tr><th>No Kwitansi</th><td>{{$qurban->kwitansi_id}}</td></tr>
                                        <tr><th>Hewan</th><td>{{$qurban->hewan}}</td></tr>
                                        <tr><th>Qty</th><td>{{$qurban->qty}}</td></tr>
                                        <tr><th>Harga</th><td>{{format_rupiah($qurban->harga)}}</td></tr>
                                        <tr><th>Total</th><td>{{format_rupiah($qurban->harga*$qurban->qty)}}</td></tr>
                                        <tr><th>Nama Pequrban</th><td>{{$qurban->pequrban}}</td></tr>
                                        <tr><th>Pesanan Khusus</th><td>{{$qurban->pesanan_khusus}}</td></tr>
                                        <tr><th>Pembayaran</th><td>{{$qurban->pembayaran}}</td></tr>
                                        <tr><th>Catatan</th><td>{{$qurban->catatan}}</td></tr>
                                  </table>

                            </div>
                            <!-- /.table-responsive -->
                            {!! link_to('qurban','Kembali',['class'=>'btn btn-default']) !!}
                        </div>
                        <!-- /.panel-body -->
                        <!--{ link_to('#','Print',['class'=>'btn btn-success']) !!}-->

                </div>
<!-- end form aplikasi qurban -->


                </div>
                <!-- /.col-lg-12 -->
              @endforeach()
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop
