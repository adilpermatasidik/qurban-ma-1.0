@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Donasi Qurban</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Donasi Qurban
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">



                                  <div class="form-group">
                                      <label>Nama Donatur</label>
                                      <p> {{ $donatur->title." ".$donatur->nama_donatur }} </p>
                                  </div>

                                  <div class="form-group">
                                      <label>Phone</label>
                                      <p>{{ $donatur->phone }}</p>
                                  </div>

                                  <div class="form-group">
                                      <label>Email</label>
                                      <p>{{ $donatur->email }}</p>
                                  </div>

                                  <div class="form-group">
                                        <label>Alamat</label>
                                      <p>{{ $donatur->alamat }}</p>
                                  </div>




                                  <div class="form-group">
                                        <label>Catatan</label>
                                      <textarea name="catatan" class="form-control">{{ $donatur->catatan }}</textarea>
                                  </div>
                                  


                                </div>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Transaksi Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                        <tr><th>Jenis Hewan</th>
                                          <td>
                                            {!! Form::select('id_hewan',
                                                             $hewans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>
                                        <tr><th>Qty</th><td>{!! Form::input('number','qty',null,['class'=>'form-control']) !!}</td></tr>
                                        <tr><th>Nama Pequrban</th>
                                          <td>
                                            {!! Form::textarea('pequrban',null,['class'=>'form-control']) !!}
                                          </td></tr>
                                        <tr><th>Pesanan Khusus</th>
                                          <td>
                                            {!! Form::select('id_pesanan',
                                                             $pesanans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>
                                        <tr><th>Pembayaran</th>
                                          <td>
                                            {!! Form::select('id_paymen',
                                                             $pembayarans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>

                                </table>
                                <input type="submit" value="Tambah" class="btn btn-success">
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                </div>



                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Donasi Hewan Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Jenis Hewan</th>
                                            <th>Qty</th>
                                            <th>Harga</th>
                                            <th>Pequrban</th>
                                            <th>Pesanan Khusus</th>
                                            <th>Pembayaran</th>
                                            <th>Acion</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Kambing</td>
                                            <td>1</td>
                                            <td>2500000</td>
                                            <td>Adil</td>
                                            <td>Tidak Ada</td>
                                            <td>Tunai</td>
                                            <td class="center">
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-default btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Ubah"><i class="fa fa-pencil"></i></a>
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Sapi</td>
                                            <td>1</td>
                                            <td>16000000</td>
                                            <td>Adil,Abdurahman</td>
                                            <td>Tidak Ada</td>
                                            <td>Tunai</td>
                                            <td class="center">
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-default btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Ubah"><i class="fa fa-pencil"></i></a>
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                            </td>
                                        </tr>
                                       <tr><th>Total Donasi</th><th colspan="7">Rp. 18.250.000,-</th></tr>
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-default">Simpan</button>
                                                <button type="reset" class="btn btn-default">Batal</button>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop
