@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Donasi Qurban</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                @foreach($qurbans as $qurban)
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Donatur Qurban
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">



                                  <div class="form-group">
                                      <label>Nama Donatur</label>
                                      <p> {{ $qurban->title." ".$qurban->nama_donatur }} </p>
                                  </div>

                                  <div class="form-group">
                                      <label>Phone</label>
                                      <p>{{ $qurban->phone }}</p>
                                  </div>

                                  <div class="form-group">
                                      <label>Email</label>
                                      <p>{{ $qurban->email }}</p>
                                  </div>

                                  <div class="form-group">
                                        <label>Alamat</label>
                                      <p>{{ $qurban->alamat }}</p>
                                  </div>

                                </div>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

<!-- form aplikasi qurban -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Transaksi Qurban
                        </div>
                        <!-- /.panel-heading -->

                        <div class="panel-body">
                            <div class="table-responsive">
                              @if((Html::ul($errors->all())))
                              <div class="alert alert-danger">
                                  {!! Html::ul($errors->all()) !!}
                              </div>
                              @endif
                                <table class="table table-striped table-bordered table-hover">
                                  {!! Form::model($qurban,array('url'=>'qurban/'.$qurban->order_id,'method'=>'patch')) !!}

                                  <tr><th>No Kwitansi</th><td>{!! Form::input('number','kwitansi_id',null,['class'=>'form-control']) !!}</td></tr>

                                        <tr><th>Jenis Hewan</th>
                                          <td>
                                            {!! Form::select('hewan_id',
                                                             $hewans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>
                                        <tr><th>Qty</th><td>{!! Form::input('number','qty',null,['class'=>'form-control']) !!}</td></tr>
                                        <tr><th>Siap Konversi</th>
                                          <td>  {!! Form::select('konversi',
                                                             array('tidak'=>'Tidak','ya'=>'Ya'),
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}</td></tr>
                                        <tr><th>Nama Pequrban</th>
                                          <td>
                                            {!! Form::textarea('pequrban',null,['class'=>'form-control']) !!}
                                          </td></tr>
                                        <tr><th>Pesanan Khusus</th>
                                          <td>
                                            {!! Form::select('pesanan_id',
                                                             $pesanans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>
                                        <tr><th>Pembayaran</th>
                                          <td>
                                            {!! Form::select('payment_id',
                                                             $pembayarans,
                                                             null,
                                                             ['class'=>'form-control'])
                                                             !!}
                                          </td></tr>
                                          <tr><th>Catatan</th>
                                            <td>
                                              {!! Form::textarea('catatan',null,['class'=>'form-control']) !!}
                                            </td></tr>

                                </table>
                                {!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
                                {!! link_to('qurban','Kembali',['class'=>'btn btn-default']) !!}
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                        {!! Form::close(); !!}
                </div>
<!-- end form aplikasi qurban -->
                @endforeach

                </div>
                <!-- /.col-lg-12 -->

            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

        @stop
