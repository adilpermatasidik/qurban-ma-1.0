@extends('template.master')
@section('content')
<div id="page-wrapper">
          <div class="row">
              <div class="col-lg-12">
                  <h1 class="page-header">
                      <div class="col-md-6">Validasi Data Donasi Qurban</div>
                      <div class="col-md-offset-6">
                          <!--<a href ="{{ url('donatur/create') }}" class="btn btn-success" data-toggle="tooltip" title="Buat Data Donatur">Add Donatur &nbsp<i class="fa fa-plus"></i></a>-->
                          <!--<a href ="{{ url('donatur') }}" class="btn btn-default" data-toggle="tooltip" title="Cari Data Donatur">Cari Donatur &nbsp<i class="fa fa-search"></i></a>-->

                          <a href ="{{ url('qurbanvalidasi') }}" class="btn btn-default" data-toggle="tooltip" title="Refresh">Refresh &nbsp;<i class="fa fa-refresh"></i></a>
                          <a href ="{{ url('qurbanvalidasi/excel') }}" class="btn btn-default"> Export Excel &nbsp;<i class="fa fa-file-excel-o"></i></a>
                      </div>
                      </h1>

              </div>

              <!-- /.col-lg-12 -->
          </div>

          <!-- cari donatur -->
          <div class="col-lg-12">
              <div class="panel panel-default">
                  <div class="panel-heading">Filter Data Donasi Qurban</div>
                   <div class="panel-body">
                      {!! Form::open(array('url'=>'qurbanvalid/cari')) !!}
                              <div class="col-md-3">
                                 {!! Form::select('kantor',
                                                  $kantors,
                                                  null,
                                                  ['class'=>'form-control'])
                                                  !!}
                              </div>
                              <div class="col-md-3">
                                 {!! Form::select('field',
                                                  array('order_qurban_details.kwitansi_id'=>'No Kwitansi',
                                                        'donaturs.name'=>'Name',
                                                        'donaturs.phone'=>'Phone',
                                                        'donaturs.email'=>'Email',
                                                        'order_qurban_details.konversi' => 'Konversi'
                                                      ),
                                                  null,
                                                  ['class'=>'form-control'])
                                                  !!}
                              </div>
                              <div class="col-md-6 input-group custom-search-form">
                                  {!! Form::text('keyword',null,['class' => 'form-control','placeholder'=>'keyword...']); !!}
                              <span class="input-group-btn">
                                  {!! Form::Submit('Cari',['class'=>'btn btn-default']) !!}
                               </div>

                      {!! Form::close() !!}
                  </div>
              </div>
          </div>
          <!-- end cari donatur -->

          <!-- /.row -->
          <div class="row">
              <div class="col-lg-12">
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          Table Donasi Qurban
                      </div>
                      <!-- /.panel-heading -->
                      <div class="panel-body">
                          <div class="table-responsive">
                              <table class="table table-bordered table-hover">
                                  <thead>
                                      <tr>
                                          <th>No</th>
                                          <th>Tanggal</th>
                                          <th>No Faktur</th>
                                          <!--<th>Donatur</th>-->
                                          <th>Pequrban</th>
                                          <th>Telepon</th>
                                          <th>Hewan</th>
                                          <th>Qty</th>
                                          <th>Harga</th>
                                          <th>Konv</th>
                                          <!--<th>Total</th>-->
                                          <th>Kantor</th>

                                          <th>Action</th>
                                      </tr>
                                  </thead>
                                  <tbody class="text-danger">

                                    <?php
                                    if(isset($_GET['page'])){
                                    $no = ($_GET['page'] - 1) * $limit;
                                    $nom = $no+1;
                                    }else
                                    {
                                        $nom = 1;
                                    }
                                    ?>

                                      @foreach($qurbans as $qurban)
                                        <?php
                                        if($qurban->valid=='no'){
                                          $text_valid = "text-danger";
                                        }else{
                                          $text_valid = "text-success";
                                        }
                                        ?>
                                      <tr class="odd gradeX <?php echo $text_valid ?>">

                                        <td><?php echo $nom; ?></td>
                                        <td>{{ $qurban->created_at }}</td>
                                        <td>{{ $qurban->kwitansi_id }}</td>
                                        <!--<td>{{ $qurban->title ." ".$qurban->nama_donatur }}</td>-->
                                        <td>{{ $qurban->pequrban }}</td>
                                        <td>{{ $qurban->phone }}</td>
                                        <td>{{ $qurban->hewan }}</td>
                                        <td>{{ $qurban->qty }}</td>
                                        <td>{{ format_rupiah($qurban->harga) }}</td>
                                        <td>{{ $qurban->konv }}</td>
                                        <td>{{ $qurban->kantor }}</td>
                                        <td>
                                          <a href ="{{ url('qurbanvalid').'/'.$qurban->order_id }}" class="btn btn-default btn-circle" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-book"></i></a>
                                          <!--<a href ="{{ url('qurbanvalid').'/'.$qurban->order_id.'/'.'edit' }}" class="btn btn-success btn-circle" data-toggle="tooltip" data-placement="bottom" title="Edit"><i class="fa fa-pencil"></i></a>-->
                                          <!--<a onclick="return confirm('Apakah anda ingin menghapus data ini?')" href ="{{ url('qurban/destroy').'/'.$qurban->order_id }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>-->
                                        </td>
                                      </tr>
                                      <?php $nom++; ?>
                                    @endforeach

                                  </tbody>
                              </table>
                              {!! $qurbans->render(); !!}

                          </div>
                          <!-- /.table-responsive -->
                      </div>
                      <!-- /.panel-body -->
                  </div>
                  <!-- /.panel -->
              </div>
              <!-- /.col-lg-12 -->
          </div>
      </div>
      <!-- /#page-wrapper -->

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

  <script>
  // tooltip demo
  $('.dataTable_wrapper').tooltip({
      selector: "[data-toggle=tooltip]",
      container: "body"
  })

  // popover demo
  $("[data-toggle=popover]")
      .popover()
  </script>

  @stop
