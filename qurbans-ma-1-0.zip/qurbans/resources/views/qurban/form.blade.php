@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Donasi Qurban</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Donasi Qurban
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form role="form">
                                        <div class="form-group">
                                            <label>Tanggal Donasi</label>
                                            <input class="form-control">
                                            <p class="help-block">Wajib Isi</p>
                                        </div>
                                         <div class="form-group">
                                            <label>Nama</label>
                                            <p>Adil Permata Sidik</p>
                                        </div>
                                         <div class="form-group">
                                            <label>HP</label>
                                            <p>085222999334</p>
                                        </div>
                                           <div class="form-group">
                                            <label>Email</label>
                                            <p>adil permata sidik@gmail.com</p>
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat</label>
                                            <p>Jl. Rawa Papan Kel. Bintaro Jakarta Selatan</p>
                                        </div>
                                        <div class="form-group">
                                            <label>Catatan</label>
                                            <textarea class="form-control" rows="3"></textarea>
                                        </div>
                                        
                                    </form>
                                </div>
                         
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Transaksi Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                        <tr><th>Jenis Hewan</th><td><select class="form-control"><option>Kambing</option><option>Sapi</option><option>Sapi 1/7</option></select></td></tr>  
                                        <tr><th>Qty</th><td><input type="number" class="form-control"></td></tr>  
                                        <tr><th>Nama Pequrban</th><td><textarea class="form-control" rows="3"></textarea></tr>  
                                        <tr><th>Pesanan Khusus</th><td><select class="form-control"><option>Tidak Ada</option><option>Sembelih di asrama</option><option>Dokumentasi</option><option>Disaksikan</option></select></td></tr>  
                                        <tr><th>Pembayaran</th><td><select class="form-control"><option>Tunai</option><option>EDC</option><option>Transfer Bank</option><option>Hewan Hidup</option></select></td></tr> 
                                        
                                </table>
                                <input type="submit" value="Tambah" class="btn btn-success">
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                </div>
                
                

                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Donasi Hewan Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Jenis Hewan</th>
                                            <th>Qty</th>
                                            <th>Harga</th>
                                            <th>Pequrban</th>
                                            <th>Pesanan Khusus</th>
                                            <th>Pembayaran</th>
                                            <th>Acion</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Kambing</td>
                                            <td>1</td>
                                            <td>2500000</td>
                                            <td>Adil</td>
                                            <td>Tidak Ada</td>
                                            <td>Tunai</td> 
                                            <td class="center">
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-default btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Ubah"><i class="fa fa-pencil"></i></a>
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Sapi</td>
                                            <td>1</td>
                                            <td>16000000</td>
                                            <td>Adil,Abdurahman</td>
                                            <td>Tidak Ada</td>
                                            <td>Tunai</td> 
                                            <td class="center">
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-default btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Ubah"><i class="fa fa-pencil"></i></a>
                                                <a href ="{{ url('qurban/form_ubah') }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                            </td>
                                        </tr>
                                       <tr><th>Total Donasi</th><th colspan="7">Rp. 18.250.000,-</th></tr>
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-default">Simpan</button>
                                                <button type="reset" class="btn btn-default">Batal</button>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop