@extends('template.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ubah Donasi Qurban</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Transaksi Qurban
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                        <tr><th>Jenis Hewan</th><td><select class="form-control"><option>Kambing</option><option>Sapi</option><option>Sapi 1/7</option></select></td></tr>  
                                        <tr><th>Qty</th><td><input type="number" class="form-control"></td></tr>  
                                        <tr><th>Nama Pequrban</th><td><textarea class="form-control" rows="3"></textarea></tr>  
                                        <tr><th>Pesanan Khusus</th><td><select class="form-control"><option>Tidak Ada</option><option>Sembelih di asrama</option><option>Dokumentasi</option><option>Disaksikan</option></select></td></tr>  
                                        <tr><th>Pembayaran</th><td><select class="form-control"><option>Tunai</option><option>EDC</option><option>Transfer Bank</option><option>Hewan Hidup</option></select></td></tr> 
                                        
                                </table>
                                <input type="submit" value="Tambah" class="btn btn-success">
                                <button value="Batal" class="btn btn-detault">Batal</button>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                </div>
                
                <!-- /.col-lg-12 -->
              
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        @stop