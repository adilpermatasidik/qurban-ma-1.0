<div class="form-group">
    <label>Nama Kota</label>
    {!! Form::text('nama_kota',null,['class'=>'form-control']) !!}
    <p class="help-block">Wajib Isi</p>
</div>
{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('kota','Kembali',['class'=>'btn btn-default']) !!}
