  @extends('template.master')
  @section('content')
  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        <div class="col-md-6">Data Kota</div>
                        <div class="col-md-offset-6">
                            <a href ="{{ url('kota/create') }}" class="btn btn-success btn-circle"><i class="fa fa-plus"></i></a>
                            <a href ="{{ url('kota') }}" class="btn btn-default btn-circle"><i class="fa fa-refresh"></i></a>

                        </div>
                        </h1>

                </div>

                <!-- /.col-lg-12 -->
            </div>

            <!-- cari kota -->
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Cari Kota</div>
                     <div class="panel-body">
                        {!! Form::open(array('url'=>'kota/search')) !!}

                                <div class="col-md-12 input-group custom-search-form">
                                    {!! Form::text('keyword',null,['class' => 'form-control','placeholder'=>'Nama Kota...']); !!}
                                <span class="input-group-btn">
                                    {!! Form::Submit('Cari',['class'=>'btn btn-default']) !!}
                                 </div>

                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
            <!-- end cari kota -->

            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Table kota
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Kota</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                      <?php
                                      if(isset($_GET['page'])){
                                      $no = ($_GET['page'] - 1) * $limit;
                                      $nom = $no+1;
                                      }else
                                      {
                                          $nom = 1;
                                      }
                                      ?>

                                        @foreach($kotas as $kota)
                                        <tr class="odd gradeX">
                                          <td><?php echo $nom; ?></td>
                                          <td>{{ $kota->nama_kota }}</td>
                                          <td>
                                            <a href ="{{ url('kota').'/'.$kota->id.'/'.'edit' }}" class="btn btn-success btn-circle" data-toggle="tooltip" data-placement="bottom" title="Edit"><i class="fa fa-pencil"></i></a>
                                            <a onclick="return confirm('Apakah anda ingin menghapus data ini?')" href ="{{ url('kota/destroy').'/'.$kota->id_kota }}" class="btn btn-danger btn-circle"  data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                                          </td>
                                        </tr>
                                        <?php $nom++; ?>
                                      @endforeach

                                    </tbody>
                                </table>
                                {!! $kotas->render(); !!}

                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <!-- /#page-wrapper -->

      <!-- Page-Level Demo Scripts - Tables - Use for reference -->

    <script>
    // tooltip demo
    $('.dataTable_wrapper').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>

    @stop
