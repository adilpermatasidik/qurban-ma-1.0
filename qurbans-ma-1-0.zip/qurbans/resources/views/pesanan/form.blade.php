<div class="form-group">
    <label>Nama Pesanan</label>
    {!! Form::text('name',null,['class'=>'form-control']) !!}
    <p class="help-block">Wajib Isi</p>
    <div class="form-group">
        <label>Aktif</label>
        {!! Form::select('aktif',
                         array('yes'=>'Ya','no'=>'Tidak'),
                         null,
                         ['class'=>'form-control'])
                         !!}
        <p class="help-block">Wajib Isi</p>
    </div>
</div>
{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('pesanan','Kembali',['class'=>'btn btn-default']) !!}
