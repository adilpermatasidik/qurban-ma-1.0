<div class="form-group">
    <label>Nama Hewan</label>
    {!! Form::text('name',null,['class'=>'form-control']) !!}
    <p class="help-block">Wajib Isi</p>
</div>

<div class="form-group">
    <label>Jenis</label>
    {!! Form::select('jenis',
                     array('sapi'=>'Sapi','domba'=>'Domba','kambing'=>'Kambing','sapi_retail'=>'Sapi Retail'),
                     null,
                     ['class'=>'form-control'])
                     !!}
    <p class="help-block">Wajib Isi</p>
</div>

<label>Berat</label>
<div class="form-group input-group">
    {!! Form::input('number','berat',null,['class'=>'form-control']) !!}
    <span class="input-group-addon">KG</span>
</div>

<label>Harga</label>
 <div class="form-group input-group">
    <span class="input-group-addon">Rp</span>
    {!! Form::input('number','harga',null,['class'=>'form-control']) !!}

</div>

{!! Form::submit('Simpan',['class'=>'btn btn-success']) !!}
{!! link_to('hewan','Kembali',['class'=>'btn btn-default']) !!}
