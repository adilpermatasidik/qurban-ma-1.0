@extends('template.master')
@section('content')
<div id="page-wrapper">
   <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data User</h1>
                </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Register user</h3>
                    </div>
                    <div class="panel-body">
                        {!! Html::ul($errors->all()) !!}
                        {!! Form::model($user,array('url'=>'auth/update/'.$user->id,'method'=>'patch')) !!}

                            <fieldset>
                                <div class="form-group">
                                    {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'Nama','autofocus']) !!}
                                </div>
                                <div class="form-group">
                                    {!! Form::email('email',null,['class'=>'form-control','placeholder'=>'Email','autofocus']) !!}
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Confirm Password" name="password_confirmation" type="password" value="">
                                </div>
                                <div class="form-group">
                                    {!! Form::select('role',array('fo'=>'FO','distributor'=>'Distributor','admin'=>'Admin','manager'=>'Manager'),null,['class'=>'form-control']) !!}

                                </div>
                                <div class="form-group">
                                  {!! Form::select('id_kantor',
                                                   $kantors,
                                                   null,
                                                   ['class'=>'form-control'])
                                                   !!}

                                </div>

                                <!-- Change this to a button or input when using this as a form -->


                                 {!! Form::Submit('Simpan Data',['class'=>'btn btn-success btn-sm']) !!}
								 {!! link_to('auth/index','Kembali',['class'=> 'btn btn-danger btn-sm']) !!}
                            </fieldset>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>

</div>
@stop
