@extends('template.master')
@section('content')
<div id="page-wrapper">
   <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Data User</h1>
                </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Register user</h3>
                    </div>
                    @if((Html::ul($errors->all())))
                    <div class="alert alert-danger">
                               {!! Html::ul($errors->all()) !!}
                    </div>
                    @endif


                    <div class="panel-body">
                        <form role="form" method="POST" action="{{ url('auth/simpan') }}">
                            {!! csrf_field() !!}
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Nama" name="name" type="text" autofocus value="{{ old('name') }}">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus value="{{ old('email') }}">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Confirm Password" name="password_confirmation" type="password" value="">
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="role">
                                        <option value="fo">FO</option>
                                        <option value="distributor">Distributor</option>
                                        <option value="admin">Admin</option>
                                        <option value="manager">Manager</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                  {!! Form::select('id_kantor',
                                                   $kantors,
                                                   null,
                                                   ['class'=>'form-control'])
                                                   !!}
                                </div>

                                <!-- Change this to a button or input when using this as a form -->

                                 <button type="submit" class="btn btn-success btn-sm">Simpan</button>
                                 {!! link_to('auth/index','Kembali',['class'=> 'btn btn-danger btn-sm']) !!}
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

</div>
@stop
