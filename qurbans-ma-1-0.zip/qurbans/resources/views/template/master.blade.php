<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="{{ asset('favicon.png') }}">

    <title>Qurban Mizan Amanah 1.0</title>

    <!-- Bootstrap Core CSS -->
    <link href="{{ asset('bower_components/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{ asset('bower_components/metisMenu/dist/metisMenu.min.css') }}" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="{{ asset('dist/css/timeline.css') }}" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ asset('dist/css/sb-admin-2.css') }}" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{ asset('bower_components/morrisjs/morris.css') }}" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{ asset('bower_components/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

        <!-- jQuery -->
    <script src="{{ asset('bower_components/jquery/dist/jquery.min.js') }}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{ asset('bower_components/metisMenu/dist/metisMenu.min.js') }}"></script>

    <!-- Custom Theme JavaScript -->
    <script src="{{ asset('dist/js/sb-admin-2.js') }}"></script>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Qurban MA 1.0</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li><a href="#"><i class="fa fa-user fa-fw"></i> {{ Auth::user()->name }}</a></li>
                <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a></li>
                <li><a href="{{ url('auth/logout') }}"><i class="fa fa-sign-out fa-fw"></i> Logout</a></li>
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{ url('dashboard') }}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                      @if(Auth::user()->role == 'fo')
                        <li>
                            <a href="{{ url('fo/pesanan') }}"><i class="fa fa-book fa-fw"></i> Qurban by Pesanan</a>
                        </li>
                      @endif
                        <li>
                            <a href="{{ url('qurban') }}"><i class="fa fa-shopping-cart fa-fw"></i> Donasi Qurban</a>
                        </li>
                      @if(Auth::user()->role == 'distributor' or Auth::user()->role == 'admin')
                        <li>
                            <a href="{{ url('qurbanvalidasi') }}"><i class="fa fa-shopping-cart fa-fw"></i> Validasi Data Qurban</a>
                        </li>
                        <li>
                            <a href="{{ url('laporan/hewanqurban') }}"><i class="fa fa-github-alt fa-fw"></i> Donasi by Hewan Qurban</a>
                        </li>
                      @endif
                      @if(Auth::user()->role == 'admin' or Auth::user()->role == 'manager' or Auth::user()->role == 'distributor')
                        <li>
                          <a href="#"><i class="fa fa-truck fa-fw"></i> Ditribusi<span class="fa arrow"></span></a>
                          <ul class="nav nav-second-level">
                            <li>
                              <a href="{{ url('distribusi') }}"><i class="fa fa-building-o fa-fw"></i>Disaksikan by Asrama</a>
                            </li>
                            <li>
                              <a href="{{ url('distribusi/kota') }}"><i class="fa fa-map-marker fa-fw"></i>Disaksikan by Kota</a>
                            </li>
                            <li>
                              <a href="{{ url('distribusi/bebas/5') }}"><i class="fa fa-globe fa-fw"></i>Distribusi Bebas</a>
                            </li>
                            <li>
                              <a href="{{ url('distribusi/bebaskota/5') }}"><i class="fa fa-globe fa-fw"></i>Distribusi Bebas Kota</a>
                            </li>
                            <li>
                              <a href="{{ url('distribusi/bebas/4') }}"><i class="fa fa-camera fa-fw"></i>Distribusi Dokumentasi</a>
                            </li>
                            <li>
                              <a href="{{ url('distribusi/bebaskota/4') }}"><i class="fa fa-camera fa-fw"></i>Distribusi Dokumentasi Kota</a>
                            </li>
                          </ul>
                        </li>

                      @endif
                        <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Data Master<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{ url('donatur') }}"><i class="fa  fa-group fa-fw"></i> Donatur</a>
                                </li>
                              @if(Auth::user()->role == 'admin')
                                <li>
                                    <a href="{{ url('hewan') }}"><i class="fa fa-github-alt fa-fw"></i> Hewan Qurban</a>
                                </li>
                              @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                      @if(Auth::user()->role == 'admin' or Auth::user()->role == 'manager')
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Laporan<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{ url('laporan/hewanqurban') }}"><i class="fa fa-github-alt fa-fw"></i> Donasi by Hewan Qurban</a>
                                </li>
                                <!--<li>
                                    <a href="{{ url('laporan/distribusi') }}"><i class="fa fa-truck fa-fw"></i> Distribusi</a>
                                </li>-->
                                <li>
                                    <a href="{{ url('laporan/grapdonasi') }}"><i class="fa fa-bar-chart-o fa-fw"></i> Grapik Donasi</a>
                                </li>
                                <li>
                                    <a href="{{ url('laporan/pequrban') }}"><i class="fa fa-group fa-fw"></i> Graphik Pequrban</a>
                                </li>
                                <li>
                                    <a href="{{ url('laporan/nominal') }}"><i class="fa fa-money fa-fw"></i> Jumlah Nominal</a>
                                </li>
                                <li>
                                    <a href="{{ url('laporan/payment/nominal') }}"><i class="fa fa-credit-card fa-fw"></i> Donasi by payment</a>
                                </li>
                                <li>
                                    <a href="{{ url('laporan/asrama/qty') }}"><i class="fa fa-building-o fa-fw"></i> Donasi by Asrama</a>
                                </li>
                                <li>
                                    <a href="{{ url('laporan/rating/nominal') }}"><i class="fa fa-star fa-fw"></i> Rating Donatur</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                      @endif
                        @if(Auth::user()->role == 'admin')
                        <li>
                            <a href="#"><i class="fa fa-gear fa-fw"></i> Pengaturan<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{ url('pembayaran') }}"><i class="fa fa-credit-card fa-fw"></i> Jenis Pembayaran</a>
                                </li>
                                <li>
                                    <a href="{{ url('pesanan') }}"><i class="fa fa-book fa-fw"></i> Pesanan Khusus</a>
                                </li>
                                <li>
                                    <a href="{{ url('kantor') }}"><i class="fa fa-building-o fa-fw"></i> Kantor Pelayanan</a>
                                </li>
                                <li>
                                    <a href="{{ url('kota') }}"><i class="fa fa-map-marker fa-fw"></i> Kota</a>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-rocket fa-fw"></i> Target Pendapatan</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i> User<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{ url('auth/index') }}"><i class="fa fa-male fa-fw"></i> Users</a>
                                </li>
                                <li>
                                    <a href="buttons.html"><i class="fa fa-users fa-fw"></i> Users Group</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


        <!-- /#page-wrapper -->
        <!-- content -->
        @yield('content')
        <!-- end content -->

    </div>
    <!-- /#wrapper -->

</body>

</html>
