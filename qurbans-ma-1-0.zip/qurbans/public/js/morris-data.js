$(function() {

    Morris.Line({
        element: 'morris-area-chart',
        data: [{
            date: '2016-08-01',
            donatur: 2666,
            qurban: 2647
        }, {
            date: '2016-08-02',
            donatur: 2778,
            qurban: 2294
        }, {
            date: '2016-08-03',
            donatur: 4912,
            qurban: 1969
        }, {
            date: '2016-08-04',
            donatur: 3767,
            qurban: 3597
        }, {
            date: '2016-08-05',
            donatur: 6810,
            qurban: 1914
        }, {
            date: '2016-08-06',
            donatur: 5670,
            qurban: 4293
        }, {
            date: '2016-08-07',
            donatur: 4820,
            qurban: 3795
        }, {
            date: '2016-08-08',
            donatur: 15073,
            qurban: 5967
        }, {
            date: '2016-08-09',
            donatur: 10687,
            qurban: 4460
        }, {
            date: '2016-08-10',
            donatur: 8432,
            qurban: 5713
        }],
        xkey: 'date',
        ykeys: ['donatur', 'qurban'],
        labels: ['donatur', 'qurban'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Sapi",
            value: 12
        }, {
            label: "Kambing",
            value: 30
        }, {
            label: "Sapi 1/7",
            value: 20
        }],
        resize: true
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [
        {y: 'Sapi',a: 100,b: 90}, 
        {y: 'Kambing',a: 100,b: 90}
        ],
        xkey: 'y',
        ykeys: ['a', 'b'],
        labels: ['Target', 'Realisasi'],
        hideHover: 'auto',
        resize: true
    });
    
});
