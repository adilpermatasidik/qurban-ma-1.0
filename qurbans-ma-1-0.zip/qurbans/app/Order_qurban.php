<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_qurban extends Model
{
    //enable field from outside
    protected $fillable = ['id_donatur','id_user','id_kantor','id_kota','total','catatan'];
}
