<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Donatur;
use Input;
use App\Kantor;
use Session;
use Validator;
use App\User;

class donaturController extends Controller
{  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */

   public function __construct(){
     $this->middleware('auth');
   }

  public function index()
  {
      //
      $data['limit'] = 10;
      $kantors = Kantor::orderBy('name','asc')->lists('name','id');
      $donaturs = \DB::table('donaturs')
                  ->select('donaturs.id',
                           'donaturs.title',
                           'donaturs.name as name',
                           'donaturs.phone',
                           'donaturs.email',
                           'donaturs.alamat',
                           'donaturs.id_user as user_id',
                           'users.name as username',
                           'kantors.name as kantor')
                  ->join('users','users.id','=','donaturs.id_user')
                  ->join('kantors','kantors.id','=','users.id_kantor')
                  ->orderBy('donaturs.name','asc')
                  ->paginate($data['limit']);


      $data['donaturs'] = $donaturs->setPath('donatur');

      return view('donatur.index',compact('kantors',$kantors))->with($data);

  }


  public function validator(array $data)
  {
      //return print_r($data);
      //die;
      $validator = Validator::make($data, [
          'name' => 'required|max:255',
          'phone' => 'required',
          'email' => 'email',
          'alamat' => 'required',
      ]);

      return $validator;

  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      return view('donatur.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      //
    //  $data = $request->all();
    $id_user = Auth::user()->id;
    $petugas = User::find($id_user);
    $idkantor = $petugas->id_kantor;
    $kantor =  Kantor::find($idkantor);

    $data = array(
                'title' => Input::get('title'),
                'name' => Input::get('name'),
                'phone' => Input::get('phone'),
                'email' => Input::get('email'),
                'alamat' => Input::get('alamat'),
                'id_user' => $id_user,
                'id_kantor' => $kantor->id
                );

      $validator = $this->validator($data);
      if($validator->fails()){
        return redirect ('donatur/create')
                        ->withErrors($validator)
                        ->withInput();
      }else{

        Donatur::create($data);

        $donaturs_last_id = Donatur::select('donaturs.id')
                            ->where('id_kantor','=',Auth::user()->id_kantor)
                            ->orderBy('donaturs.id','desc')
                            ->take(1)
                            ->get();

        $id_last = (int) $donaturs_last_id['0']['id'];
        return redirect()->action('donaturController@tampil',[$id_last]);
      }


  }

  public function tampil($id)
  {
    $donaturs_last_id = Donatur::find($id);
    $data['donaturs'] = $donaturs_last_id;
    //return $data['donaturs'];
    return view('donatur.tampil',$data);

  }


  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {

      $data['limit'] = 10;
      $donatur = Donatur::find($id);
      $data['donatur'] = $donatur;
      $qurbans = \DB::table('order_qurban_details')
                 ->select(
        'order_qurban_details.id as order_id',
        'order_qurban_details.donatur_id',
        'order_qurban_details.kwitansi_id as kwitansi_id',
        'order_qurban_details.created_at as created_at',
        'order_qurban_details.qty as qty',
        'order_qurban_details.pequrban as pequrban',
        'donaturs.title as title',
        'donaturs.name as nama_donatur',
        'donaturs.phone as phone',
        'kantors.name as kantor',
        'pesanans.name as pesanan',
        'pembayarans.name as payment',
        'users.name as petugas',
        'hewans.name as hewan',
        'hewans.harga as harga',
        'hewans.harga * order_qurban_details.qty as total')
        ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
        ->join('users','users.id','=','order_qurban_details.user_id')
        ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
        ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
        ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
        ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
        ->where('order_qurban_details.donatur_id','=',$id)
        ->orderBy('order_qurban_details.created_at')
        ->paginate($data['limit']);

      $data['qurbans'] = $qurbans->setPath('donatur/'.$id);
      //return $data['qurbans'];
      return view('donatur.show',$data);
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
   public function edit($id){
       $donatur = Donatur::find($id);
      // $kotas = Kota::orderBy('nama_kota', 'asc')->lists('nama_kota','id');
       $data['donatur'] = $donatur;
       return view('donatur.edit',$data);
   }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
      //
      $data = $request->all();

      $validator = $this->validator($data);

      if($validator->fails()){
        return redirect ('donatur/edit')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        $donatur = Donatur::find($id);
        $donatur->update($data);
        return redirect('donatur');
      }


  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
      //K
      $donatur = Donatur::find($id);
      $donatur->delete();
      return redirect('donatur');
  }

  public function search(Request $request){
    //pencarian

    // id all 4
    $kantor = $request['kantor'];
    $field = $request['field'];
    $keyword = "%".$request['keyword']."%";
    //$donaturs = Donatur::where($field,'like',$keyword)->paginate(10);


    if($kantor == '4')
    {
      #jika kondisi kantor all dan keyword di isi
      $donaturs = \DB::table('donaturs')
                  ->select('donaturs.id',
                           'donaturs.title',
                           'donaturs.name as name',
                           'donaturs.phone',
                           'donaturs.email',
                           'donaturs.alamat',
                           'users.id as user_id',
                           'users.name as username',
                           'kantors.name as kantor')
                  ->join('users','users.id','=','donaturs.id_user')
                  ->join('kantors','kantors.id','=','users.id_kantor')
                  ->where($field,'like',$keyword)
                  ->orderBy('donaturs.name','asc')
                  ->paginate(10);
                  $data['donaturs'] = $donaturs->setPath('donatur/search');
    }
    elseif($keyword == '' && $kantor != '4')
    {
      #jika kondisi kantor tidak all dan keyword tidak di isi
      $donaturs = \DB::table('donaturs')
                  ->select('donaturs.id',
                           'donaturs.title',
                           'donaturs.name as name',
                           'donaturs.phone',
                           'donaturs.email',
                           'donaturs.alamat',
                           'users.id as user_id',
                           'users.name as username',
                           'kantors.name as kantor')
                  ->join('users','users.id','=','donaturs.id_user')
                  ->join('kantors','kantors.id','=','users.id_kantor')
                  ->where('kantors.id','like',$kantor)
                  ->orderBy('donaturs.name','asc')
                  ->paginate(10);
                  $data['donaturs'] = $donaturs->setPath('donatur/search');
    }else{
      $donaturs = \DB::table('donaturs')
                  ->select('donaturs.id',
                           'donaturs.title',
                           'donaturs.name as name',
                           'donaturs.phone',
                           'donaturs.email',
                           'donaturs.alamat',
                           'users.id as user_id',
                           'users.name as username',
                           'kantors.name as kantor')
                  ->join('users','users.id','=','donaturs.id_user')
                  ->join('kantors','kantors.id','=','users.id_kantor')
                  ->where('kantors.id','like',$kantor)->where($field,'like',$keyword)
                  ->orderBy('donaturs.name','asc')
                  ->paginate(10);
                  $data['donaturs'] = $donaturs->setPath('search');
    }



    $kantors = Kantor::orderBy('name','asc')->lists('name','id');

    return view('donatur.index',compact('kantors',$kantors))->with($data);

  }
}
