<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Kota;
use App\Kantor;
use App\Pesanan;
use App\Pembayaran;
use App\User;
use App\Hewan;
use App\Donatur;
use App\Order_qurban;
use App\Order_qurban_detail;
use Input;
use Session;
use Validator;

class orderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function __construct(){
       $this->middleware('auth');
     }

    public function index()
    {

        $data['limit'] = 10;
        $kantors = Kantor::orderBy('name','asc')->lists('name','id');

        if(Auth::user()->role == 'fo'){
        $qurbans = \DB::table('order_qurban_details')
                   ->select(
  		    'order_qurban_details.id as order_id',
          'order_qurban_details.kwitansi_id as kwitansi_id',
          'order_qurban_details.created_at as created_at',
          'order_qurban_details.qty as qty',
          'order_qurban_details.pequrban as pequrban',
          'order_qurban_details.konversi as konv',
          'order_qurban_details.user_id as user_id',
          'donaturs.title as title',
          'donaturs.name as nama_donatur',
          'donaturs.phone as phone',
          'kantors.name as kantor',
          'users.name as petugas',
          'hewans.name as hewan',
          'hewans.harga as harga',
          'hewans.harga * order_qurban_details.qty as total')
          ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
          ->join('users','users.id','=','order_qurban_details.user_id')
          ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
          ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
          ->orderBy('order_qurban_details.created_at','desc')
          ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
          ->paginate($data['limit']);
        }
        else{
          $qurbans = \DB::table('order_qurban_details')
                     ->select(
    		    'order_qurban_details.id as order_id',
            'order_qurban_details.kwitansi_id as kwitansi_id',
            'order_qurban_details.created_at as created_at',
            'order_qurban_details.qty as qty',
            'order_qurban_details.pequrban as pequrban',
            'order_qurban_details.konversi as konv',
            'order_qurban_details.user_id as user_id',
            'donaturs.title as title',
            'donaturs.name as nama_donatur',
            'donaturs.phone as phone',
            'kantors.name as kantor',
            'users.name as petugas',
            'hewans.name as hewan',
            'hewans.harga as harga',
            'hewans.harga * order_qurban_details.qty as total')
            ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
            ->join('users','users.id','=','order_qurban_details.user_id')
            ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
            ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
            ->orderBy('order_qurban_details.created_at','desc')
            ->paginate($data['limit']);
        }

        $data['qurbans'] = $qurbans->setPath('');
        return view('qurban.index',compact('kantors',$kantors))->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function add($id){
       $donatur = Donatur::find($id);
       $data['donaturs'] = $donatur;
       return view('qurban.create',$data);
     }

     public function buatdonasi($id)
     {

       $data_donatur = \DB::table('donaturs')->select('donaturs.id as id_donatur','donaturs.id_kantor as id_kantor','kantors.id_kota as id_kota')
                        ->join('kantors','kantors.id','=','donaturs.id_kantor')
                        ->where('donaturs.id','=',$id)
                        ->get();
       $user_by = Auth::user()->id;
       $data = array(
                    'id_user'   => $user_by,
                    'id_donatur' => $data_donatur[0]->id_donatur,
                    'id_kantor' => $data_donatur[0]->id_kantor,
                    'id_kota'   => $data_donatur[0]->id_kota,
                    'total'     => 0,
                    'catatan'   => ""
       );


     }

     public function addItem($id){
       //list data hewan for select hewan qurban
       $donatur      = Donatur::find($id);
       $hewans       = Hewan::orderBy('name','asc')->lists('name','id');
       $pesanans     = Pesanan::where('aktif','=','yes')->orderBy('name','desc')->lists('name','id');
       $pembayarans  = Pembayaran::orderBy('name','desc')->lists('name','id');

       $data['donatur'] = $donatur;
       return view('qurban.tambah',compact('hewans',$hewans))
                    ->with($data)
                    ->with(compact('pesanans',$pesanans))
                    ->with(compact('pembayarans',$pembayarans));
     }

    public function create()
    {
        //

        //return view('qurban.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = $request->all();
        $kantor_id_user = Auth::user()->id_kantor;
        $kota_id = Kantor::select('id_kota')->find($kantor_id_user);

        $validator = $this->validator($data);
        if($validator->fails()){
          return redirect ('qurban/addItem/'.Input::get('donatur_id'))
                          ->withErrors($validator)
                          ->withInput();
        }else{

              if(Input::get('pesanan_id') == 1 or Input::get('pesanan_id') == 2){
                    $distribusi_id = $kantor_id_user;
              }else{
                    $distribusi_id = 0;
              }

          $data = array(
                 'kwitansi_id' => Input::get('kwitansi_id'),
                 'donatur_id' => Input::get('donatur_id'),
                 'hewan_id' => Input::get('hewan_id'),
                 'qty' => Input::get('qty'),
                 'konversi' => Input::get('konversi'),
                 'pequrban' => Input::get('pequrban'),
                 'pesanan_id' => Input::get('pesanan_id'),
                 'payment_id' => Input::get('payment_id'),
                 'user_id' => Auth::user()->id,
                 'kantor_id' => Auth::user()->id_kantor,
                 'distribusi_id' => $distribusi_id,
                 'kota_id' => $kota_id->id_kota,
                 'catatan' => Input::get('catatan')
                 );

          Order_qurban_detail::create($data);
          return redirect('qurban');

        }
    }

    public function validator(array $data)
    {
        //return print_r($data);
        //die;
        $validator = Validator::make($data, [
            'kwitansi_id' => 'required|max:4',
            'hewan_id' => 'required',
            'qty' => 'required',
            'pequrban' => 'required',
            'pesanan_id' => 'required',
            'payment_id' => 'required',
            'konversi' => 'required',

        ]);

        return $validator;

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

      $qurbans = \DB::table('order_qurban_details')
                 ->select(
        'order_qurban_details.id as order_id',
        'order_qurban_details.kwitansi_id as kwitansi_id',
        'order_qurban_details.created_at as created_at',
        'order_qurban_details.qty as qty',
        'order_qurban_details.pequrban as pequrban',
        'order_qurban_details.catatan as catatan',
        'order_qurban_details.konversi as konversi',
        'donaturs.title as title',
        'donaturs.name as nama_donatur',
        'donaturs.phone as phone',
        'donaturs.email as email',
        'donaturs.alamat as alamat',
        'kantors.name as kantor',
        'users.name as petugas',
        'pesanans.name as pesanan_khusus',
        'pembayarans.name as pembayaran',
        'hewans.name as hewan',
        'hewans.harga as harga',
        'hewans.harga * order_qurban_details.qty as total')
        ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
        ->join('users','users.id','=','order_qurban_details.user_id')
        ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
        ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
        ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
        ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
        ->orderBy('order_qurban_details.created_at')
        ->where('order_qurban_details.id','=',$id)
        ->get();

      $data['qurbans'] = $qurbans;
      return view('qurban.show',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $qurbans = \DB::table('order_qurban_details')
                 ->select(
        'order_qurban_details.id as order_id',
        'order_qurban_details.kwitansi_id as kwitansi_id',
        'order_qurban_details.created_at as created_at',
        'order_qurban_details.qty as qty',
        'order_qurban_details.pequrban as pequrban',
        'order_qurban_details.catatan as catatan',
        'order_qurban_details.hewan_id as hewan_id',
        'order_qurban_details.pesanan_id as pesanan_id',
        'order_qurban_details.payment_id as payment_id',
        'order_qurban_details.konversi as konversi',
        'donaturs.title as title',
        'donaturs.name as nama_donatur',
        'donaturs.phone as phone',
        'donaturs.email as email',
        'donaturs.alamat as alamat',
        'kantors.name as kantor',
        'users.name as petugas',
        'pesanans.name as pesanan_khusus',
        'pembayarans.name as pembayaran',
        'hewans.name as hewan',
        'hewans.harga as harga',
        'hewans.harga * order_qurban_details.qty as total')
        ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
        ->join('users','users.id','=','order_qurban_details.user_id')
        ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
        ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
        ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
        ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
        ->orderBy('order_qurban_details.created_at')
        ->where('order_qurban_details.id','=',$id)
        ->get();


        $hewans       = Hewan::orderBy('name','asc')->lists('name','id');
        $pesanans     = Pesanan::orderBy('name','desc')->lists('name','id');
        $pembayarans  = Pembayaran::orderBy('name','desc')->lists('name','id');



      $data['qurbans'] = $qurbans;
      //return $qurbans[0]->order_id;
      return view('qurban.edit',$data)
                  ->with(compact('hewans',$hewans))
                  ->with(compact('pesanans',$pesanans))
                  ->with(compact('pembayarans',$pembayarans));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      //
      $data = $request->all();
      $kantor_id_user = Auth::user()->id_kantor;
      $kota_id = Kantor::select('id_kota')->find($kantor_id_user);
	
      $validator = $this->validator($data);
      if($validator->fails()){
	if(Input::get('valid')){
        	return redirect ('qurbanvalid/'.$id)
                        ->withErrors($validator)
                        ->withInput();
	}else{
		          return redirect ('qurban/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();
		}
      }else{

        if(Input::get('pesanan_id') == 1 or Input::get('pesanan_id') == 2){
              $distribusi_id = $kantor_id_user;
        }else{
              $distribusi_id = 0;
        }

        if(Input::get('valid')){
          $valid = Input::get('valid');
            $data = array(
               'kwitansi_id' => Input::get('kwitansi_id'),
               'hewan_id' => Input::get('hewan_id'),
               'qty' => Input::get('qty'),
               'konversi' => Input::get('konversi'),
               'pequrban' => Input::get('pequrban'),
               'pesanan_id' => Input::get('pesanan_id'),
               'payment_id' => Input::get('payment_id'),
               'distribusi_id' => $distribusi_id,
               'kota_id' => $kota_id->id_kota,
               'catatan' => Input::get('catatan'),
               'valid' => $valid
               );
        }else{
          $valid = "no";
          $data = array(
               'kwitansi_id' => Input::get('kwitansi_id'),
               'hewan_id' => Input::get('hewan_id'),
               'qty' => Input::get('qty'),
               'konversi' => Input::get('konversi'),
               'pequrban' => Input::get('pequrban'),
               'pesanan_id' => Input::get('pesanan_id'),
               'payment_id' => Input::get('payment_id'),
               'distribusi_id' => $distribusi_id,
               'kota_id' => $kota_id->id_kota,
               'catatan' => Input::get('catatan'),
               'valid' => $valid
               );
        }

       


        $order_detail = Order_qurban_detail::find($id);
        $order_detail->update($data);

        if(Input::get('valid')){
          return redirect('qurbanvalidasi');
        }else{
          return redirect('qurban');
        }


      }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function search(Request $request){
       //pencarian

       // id all 4
       $kantor = $request['kantor'];
       $field = $request['field'];
       $keyword = "%".$request['keyword']."%";
       //$donaturs = Donatur::where($field,'like',$keyword)->paginate(10);
       $data['limit'] = 100;

       if($kantor == '4')
       {
         #jika kondisi kantor all dan keyword di isi
         $qurbans = \DB::table('order_qurban_details')
                    ->select(
   		    'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.user_id as user_id',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where($field,'like',$keyword)
           ->orderBy('order_qurban_details.created_at','desc')
           ->paginate($data['limit']);

       }
       elseif($keyword == '' && $kantor != '4')
       {
         #jika kondisi kantor tidak all dan keyword tidak di isi

         $qurbans = \DB::table('order_qurban_details')
                    ->select(
   		    'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.user_id as user_id',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where('kantors.id','like',$kantor)
           ->orderBy('order_qurban_details.created_at','desc')
           ->paginate($data['limit']);

       }else{

         $qurbans = \DB::table('order_qurban_details')
                    ->select(
   		    'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.user_id as user_id',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where('kantors.id','like',$kantor)->where($field,'like',$keyword)
           ->orderBy('order_qurban_details.created_at','desc')
           ->paginate($data['limit']);

       }



      $kantors = Kantor::orderBy('name','asc')->lists('name','id');

      $data['qurbans'] = $qurbans;
      return view('qurban.index',compact('kantors',$kantors))->with($data);

     }

     public function validasi(){
       $data['limit'] = 10;
       $kantors = Kantor::orderBy('name','asc')->lists('name','id');

       $qurbans = \DB::table('order_qurban_details')
                  ->select(
         'order_qurban_details.id as order_id',
         'order_qurban_details.kwitansi_id as kwitansi_id',
         'order_qurban_details.created_at as created_at',
         'order_qurban_details.qty as qty',
         'order_qurban_details.pequrban as pequrban',
         'order_qurban_details.konversi as konv',
         'order_qurban_details.valid as valid',
         'donaturs.title as title',
         'donaturs.name as nama_donatur',
         'donaturs.phone as phone',
         'kantors.name as kantor',
         'users.name as petugas',
         'hewans.name as hewan',
         'hewans.harga as harga',
         'hewans.harga * order_qurban_details.qty as total')
         ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
         ->join('users','users.id','=','order_qurban_details.user_id')
         ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
         ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
         ->orderBy('order_qurban_details.created_at','desc')
         ->paginate($data['limit']);

       $data['qurbans'] = $qurbans->setPath('');
       return view('qurban.validasi',compact('kantors',$kantors))->with($data);
     }

     public function valid($id){
       $qurbans = \DB::table('order_qurban_details')
                  ->select(
         'order_qurban_details.id as order_id',
         'order_qurban_details.kwitansi_id as kwitansi_id',
         'order_qurban_details.created_at as created_at',
         'order_qurban_details.qty as qty',
         'order_qurban_details.pequrban as pequrban',
         'order_qurban_details.catatan as catatan',
         'order_qurban_details.hewan_id as hewan_id',
         'order_qurban_details.pesanan_id as pesanan_id',
         'order_qurban_details.payment_id as payment_id',
         'order_qurban_details.konversi as konversi',
         'order_qurban_details.valid as valid',
         'donaturs.title as title',
         'donaturs.name as nama_donatur',
         'donaturs.phone as phone',
         'donaturs.email as email',
         'donaturs.alamat as alamat',
         'kantors.name as kantor',
         'users.name as petugas',
         'pesanans.name as pesanan_khusus',
         'pembayarans.name as pembayaran',
         'hewans.name as hewan',
         'hewans.harga as harga',
         'hewans.harga * order_qurban_details.qty as total')
         ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
         ->join('users','users.id','=','order_qurban_details.user_id')
         ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
         ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
         ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
         ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
         ->orderBy('order_qurban_details.created_at')
         ->where('order_qurban_details.id','=',$id)
         ->get();


         $hewans       = Hewan::orderBy('name','asc')->lists('name','id');
         $pesanans     = Pesanan::orderBy('name','desc')->lists('name','id');
         $pembayarans  = Pembayaran::orderBy('name','desc')->lists('name','id');



       $data['qurbans'] = $qurbans;
       //return $qurbans[0]->order_id;
       return view('qurban.validedit',$data)
                   ->with(compact('hewans',$hewans))
                   ->with(compact('pesanans',$pesanans))
                   ->with(compact('pembayarans',$pembayarans));
     }

     public function cari(Request $request){
       //pencarian

       // id all 4
       $kantor = $request['kantor'];
       $field = $request['field'];
       $keyword = "%".$request['keyword']."%";
       //$donaturs = Donatur::where($field,'like',$keyword)->paginate(10);


       if($kantor == '4')
       {
         #jika kondisi kantor all dan keyword di isi
         $qurbans = \DB::table('order_qurban_details')
                    ->select(
           'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.valid as valid',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where($field,'like',$keyword)
           ->orderBy('order_qurban_details.created_at','desc')
           #->get();
           ->paginate(100);

       }
       elseif($keyword == '' && $kantor != '4')
       {
         #jika kondisi kantor tidak all dan keyword tidak di isi

         $qurbans = \DB::table('order_qurban_details')
                    ->select(
           'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.valid as valid',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where('kantors.id','like',$kantor)
           ->orderBy('order_qurban_details.created_at','desc')
           ->paginate(100);
           #->get();

       }else{

         $qurbans = \DB::table('order_qurban_details')
                    ->select(
           'order_qurban_details.id as order_id',
           'order_qurban_details.kwitansi_id as kwitansi_id',
           'order_qurban_details.created_at as created_at',
           'order_qurban_details.qty as qty',
           'order_qurban_details.konversi as konv',
           'order_qurban_details.pequrban as pequrban',
           'order_qurban_details.valid as valid',
           'donaturs.title as title',
           'donaturs.name as nama_donatur',
           'donaturs.phone as phone',
           'kantors.name as kantor',
           'users.name as petugas',
           'hewans.name as hewan',
           'hewans.harga as harga',
           'hewans.harga * order_qurban_details.qty as total')
           ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
           ->join('users','users.id','=','order_qurban_details.user_id')
           ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
           ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
           ->where('kantors.id','like',$kantor)->where($field,'like',$keyword)
           ->orderBy('order_qurban_details.created_at','desc')
           ->paginate(100);
           #->get();

       }



      $kantors = Kantor::orderBy('name','asc')->lists('name','id');

      $data['qurbans'] = $qurbans->setPath('');
      return view('qurban.validasi',compact('kantors',$kantors))->with($data);

     }

     public function excel(){
       $total = \DB::raw('(hewans.harga * order_qurban_details.qty) as total');
       $qurbans = \DB::table('order_qurban_details')
                  ->select(
         'order_qurban_details.id as order_id',
         'order_qurban_details.kwitansi_id as kwitansi_id',
         'order_qurban_details.created_at as created_at',
         'order_qurban_details.qty as qty',
         'order_qurban_details.pequrban as pequrban',
         'order_qurban_details.catatan as catatan',
         'order_qurban_details.hewan_id as hewan_id',
         'order_qurban_details.pesanan_id as pesanan_id',
         'order_qurban_details.payment_id as payment_id',
         'order_qurban_details.konversi as konversi',
         'order_qurban_details.valid as valid',
         'donaturs.title as title',
         'donaturs.name as nama_donatur',
         'donaturs.phone as phone',
         'donaturs.email as email',
         'donaturs.alamat as alamat',
         'kantors.name as kantor',
         'kotas.nama_kota as kota',
         'users.name as petugas',
         'pesanans.name as pesanan_khusus',
         'pembayarans.name as pembayaran',
         'hewans.name as hewan',
         'hewans.harga as harga',
          $total
          )
         ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
         ->join('users','users.id','=','order_qurban_details.user_id')
         ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
         ->join('kotas','kotas.id','=','order_qurban_details.kota_id')
         ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
         ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
         ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
         ->orderBy('order_qurban_details.created_at')
         #->limit(1,0)
         ->get();

         \Excel::create('Data Qurban Mizan Amanah '.date('Y'),function($excel) use ($qurbans)
         {
            $excel->sheet('data qurban',function($sheet) use ($qurbans)
            {

                 $row=2;
                 $sheet->row(1,array(
                     'Data', 'Qurban ','Mizan Amanah ',date('Y')
                   ));
                 $sheet->row(2,array(
                     'No',
                     'Nama Donatur',
                     'Phone',
                     'Email',
                     'Alamat',
                     'No Kwitansi',
                     'Hewan',
                     'Qty',
                     'Harga',
                     'Total',
                     'Konversi',
                     'Pequrban',
                     'Pesanan',
                     'Pembayaran',
                     'Catatan',
                     'valid',
                     'petugas',
                     'kantor',
                     'kota'
                   ));

                 $no = 1;
                 foreach($qurbans as $dd){
                     $sheet->row(++$row,array(
                         $no,
                         $dd->nama_donatur,
                         $dd->phone,
                         $dd->email,
                         $dd->alamat,
                         $dd->kwitansi_id,
                         $dd->hewan,
                         $dd->qty,
                         $dd->harga,
                         $dd->total,
                         $dd->konversi,
                         $dd->pequrban,
                         $dd->pesanan_khusus,
                         $dd->pembayaran,
                         $dd->catatan,
                         $dd->valid,
                         $dd->petugas,
                         $dd->kantor,
                         $dd->kota


                       ));
                     $no++;
                 }
            });
         })->export('xls');

         #return $qurbans;
     }



}
