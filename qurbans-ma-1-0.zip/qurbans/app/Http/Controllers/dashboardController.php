<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Kota;
use App\Kantor;
use App\Pesanan;
use App\Pembayaran;
use App\User;
use App\Hewan;
use App\Donatur;
use App\Order_qurban;
use App\Order_qurban_detail;
use Input;
use Session;
use Validator;

class dashboardController extends Controller
{

  public function __construct(){
    $this->middleware('auth');
  }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


      #list alamat kantor
      $kantors = Kantor::orderBy('name','asc')->lists('name','id');


      #qurban by date
      $data['qurban_by_date_qty'] = $this->grapdate('qty');
      $data['qurban_by_date_nominal'] = $this->grapdate('nominal');



      #qurban to day
      $data['qurban_to_day_qty'] = $this->qurbanToDay('qty');
      $data['qurban_to_day_nominal'] = $this->qurbanToDay('nominal');

      #qurban by asrama all
      $data['qurban_by_asrama_qty'] = $this->qurbanqty();
      $data['qurban_by_asrama_nominal'] = $this->qurbannominal();



      #return $data['qurban_asrama_dokumentasi'];
      return view('dashboard',compact('kantors',$kantors))->with($data);
    }

    public function pagePesanan(){
      #qurban by asrama disaksikan
      $data['qurban_asrama_disaksikan'] = $this->grappesanan(2);

      #qurban by asrama dokumentasi
      $data['qurban_asrama_dokumentasi'] = $this->grappesanan(4);

      #qurban by asrama bebas
      $data['qurban_asrama_bebas'] = $this->grappesanan(5);
      return view('fo.pesanan',$data);
    }

    public function grappesanan($pesanan_id){



      #query data qurban
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.pesanan_id ='.$pesanan_id.' AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 AND order_qurban_details.pesanan_id ='.$pesanan_id.' and order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_pesanan = \DB::table('order_qurban_details')
                                       ->select('kantors.id as kantor_id',
                                                'kantors.name as nama_kantor',
                                                'kotas.nama_kota as nama_kota',

                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                       ->join('kotas','kotas.id','=','kantors.id_kota')
                                       ->groupBy('order_qurban_details.kantor_id')
                                       ->orderBy('kantors.name','asc')
                                       ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
                                       ->where('order_qurban_details.pesanan_id','=',$pesanan_id)
                                       ->get();
                                       #->paginate(50);

      #$data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('nominal');
      return $qurban_pesanan;
    }

    public function grapdate($jenis){
      #query graphic qurban by tanggal
      if($jenis=='qty'){
      $selec_raw_date = \DB::raw('sum(order_qurban_details.qty) as qty,
                                DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d") as date');
          }
      elseif($jenis=='nominal'){
      $selec_raw_date = \DB::raw('sum(hewans.harga) as harga,
                                DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d") as date');
      }

      $timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');
      $grap_quban_by_date = \DB::table('order_qurban_details')
                                    ->select($selec_raw_date)
                                    ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                    ->groupBy($timestamp_to_date)
                                    ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
                                    ->get();
      return $grap_quban_by_date;
    }

    public function qurbanToDay($jenis){
      #query graphic bulat qurban by nama hewan
      if($jenis=="qty"){
      $selec_raw_hewan = \DB::raw('hewans.name as nama_hewan,
                                sum(order_qurban_details.qty) as qty');
      }elseif($jenis=="nominal"){
      $selec_raw_hewan = \DB::raw('hewans.name as nama_hewan,
                                  sum(hewans.harga) as harga');
      }

      $timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');

      $qurbanToDay = \DB::table('order_qurban_details')
                                  ->select($selec_raw_hewan)
                                  ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                  ->groupBy('order_qurban_details.hewan_id')
                                  ->orderBy('hewans.name')
                                  ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
                                  ->where($timestamp_to_date,'=',date('Y-m-d'))
                                  ->get();
      return $qurbanToDay;
    }

    public function qurbanqty(){
      #query data qurban
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 and order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_asrama = \DB::table('order_qurban_details')
                                       ->select('kantors.id as kantor_id',
                                                'kantors.name as nama_kantor',
                                                'kotas.nama_kota as nama_kota',

                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                       ->join('kotas','kotas.id','=','kantors.id_kota')
                                       ->groupBy('order_qurban_details.kantor_id')
                                       ->orderBy('kantors.name','asc')
                                       ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
                                       ->get();
                                       #->paginate(50);

      #$data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('nominal');
      return $qurban_asrama;
    }

    public function qurbannominal(){
      #query data qurban
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(hewans.harga),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 and order_qurban_details.kantor_id = '.Auth::user()->id_kantor.') as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_asrama = \DB::table('order_qurban_details')
                                       ->select('kantors.id as kantor_id',
                                                'kantors.name as nama_kantor',
                                                'kotas.nama_kota as nama_kota',

                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                       ->join('kotas','kotas.id','=','kantors.id_kota')
                                       ->groupBy('order_qurban_details.kantor_id')
                                       ->orderBy('kantors.name','asc')
                                       ->where('order_qurban_details.kantor_id','=',Auth::user()->id_kantor)
                                       ->get();
                                       #->paginate(50);

      #$data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('nominal');
      return $qurban_asrama;
    }

}
