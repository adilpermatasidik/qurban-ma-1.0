<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Kota;
use App\Kantor;
use App\Pesanan;
use App\Pembayaran;
use App\User;
use App\Hewan;
use App\Donatur;
use App\Order_qurban;
use App\Order_qurban_detail;
use Input;
use Session;
use Validator;

class distribusiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function __construct(){
       $this->middleware('auth');
     }

    public function index()
    {
        $data['limit'] = 10;
        #cari jumlah domba A
        $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                             FROM order_qurban_details
                             JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                             JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                             WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as domba_a');
        #cari jumlah domba b
        $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 6 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as domba_b');

        #cari jumlah sapi sapi_super
        $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 1 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_super');

        #cari jumlah sapi standar
        $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 2 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_standar');

        #cari jumlah sapi 1/7 A
        $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 3 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_a');

        #cari jumlah sapi 1/7 B
        $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 4 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_b');

        #cari jumlah domba_hidup
        $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 9 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as domba_hidup');

        #cari jumlah kambing_hidup
        $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                                FROM order_qurban_details
                                JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                                JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                                WHERE hewans.id = 8 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kantor_id = kantors.id) as kambing_hidup');

        #cari jumlah kambing_hidup
        $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                                from order_qurban_details
                                join hewans on hewans.id = order_qurban_details.hewan_id
                                join pesanans on pesanans.id = order_qurban_details.pesanan_id
                                where hewans.id = 7 and order_qurban_details.pesanan_id = 2 and order_qurban_details.kantor_id = kantors.id) as sapi_hidup');


        #query qurban by asrama where pesanan = disaksikan
        $qurban_asrama_disaksikan = \DB::table('order_qurban_details')
                                         ->select('kantors.id as kantor_id',
                                                  'kantors.name as nama_kantor',
                                                  'kotas.nama_kota as nama_kota',

                                                  $domba_a,
                                                  $domba_b,
                                                  $sapi_super,
                                                  $sapi_standar,
                                                  $sapi_r_a,
                                                  $sapi_r_b,
                                                  $domba_hidup,
                                                  $kambing_hidup,
                                                  $sapi_hidup
                                                )
                                         ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                         ->join('kotas','kotas.id','=','kantors.id_kota')
                                         ->groupBy('order_qurban_details.kantor_id')
                                         ->orderBy('kantors.name','asc')
                                         ->paginate(50);

        $data['text'] = "Disaksikan";
        $data['pesanan_id'] = 2;
        $data['kembali'] = 'distribusi';
        $data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('distribusi');
        return view('distribusi.head.index',$data);
    }

    public function disaksikanKota(){
      $data['limit'] = 10;
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.pesanan_id = 2 AND order_qurban_details.kota_id = kotas.id) as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 and order_qurban_details.pesanan_id = 2 and order_qurban_details.kota_id = kotas.id) as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_asrama_disaksikan = \DB::table('order_qurban_details')
                                       ->select('kotas.id as kotas_id',
                                                'kotas.nama_kota as nama_kota',
                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kotas','kotas.id','=','order_qurban_details.kota_id')
                                       ->groupBy('order_qurban_details.kota_id')
                                       ->orderBy('kotas.nama_kota','asc')
                                       ->paginate(100);
      $data['text'] = "Disaksikan";
      $data['kembali'] = 'distribusi/kota';
      $data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('qurban');
      return view('distribusi.head.kota',$data);
    }

    public function distBebas($pesanan_id){
      $data['limit'] = 10;
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kantor_id = kantors.id) as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 and order_qurban_details.pesanan_id = '.$pesanan_id.' and order_qurban_details.kantor_id = kantors.id) as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_asrama_disaksikan = \DB::table('order_qurban_details')
                                       ->select('kantors.id as kantor_id',
                                                'kantors.name as nama_kantor',
                                                'kotas.nama_kota as nama_kota',
                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                       ->join('kotas','kotas.id','=','kantors.id_kota')
                                       ->groupBy('order_qurban_details.kantor_id')
                                       ->orderBy('kantors.name','asc')
                                       ->paginate(50);

      if($pesanan_id==5){
      $data['text'] = "Bebas";
    }elseif($pesanan_id==4){
      $data['text'] = "Dokumentasi";
    }
      $data['kembali'] = 'distribusi/bebas/'.$pesanan_id;
      $data['pesanan_id'] = $pesanan_id;
      $data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('distribusi');
      return view('distribusi.head.index',$data);
    }

    public function distBebasKota($pesanan_id){
      $data['limit'] = 10;
      #cari jumlah domba A
      $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                           FROM order_qurban_details
                           JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                           JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                           WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as domba_a');
      #cari jumlah domba b
      $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 6 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as domba_b');

      #cari jumlah sapi sapi_super
      $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 1 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as sapi_super');

      #cari jumlah sapi standar
      $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 2 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as sapi_standar');

      #cari jumlah sapi 1/7 A
      $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 3 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as sapi_r_a');

      #cari jumlah sapi 1/7 B
      $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 4 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as sapi_r_b');

      #cari jumlah domba_hidup
      $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                          FROM order_qurban_details
                          JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                          JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                          WHERE hewans.id = 9 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as domba_hidup');

      #cari jumlah kambing_hidup
      $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                              FROM order_qurban_details
                              JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                              JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                              WHERE hewans.id = 8 AND order_qurban_details.pesanan_id = '.$pesanan_id.' AND order_qurban_details.kota_id = kotas.id) as kambing_hidup');

      #cari jumlah kambing_hidup
      $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                              from order_qurban_details
                              join hewans on hewans.id = order_qurban_details.hewan_id
                              join pesanans on pesanans.id = order_qurban_details.pesanan_id
                              where hewans.id = 7 and order_qurban_details.pesanan_id = '.$pesanan_id.' and order_qurban_details.kota_id = kotas.id) as sapi_hidup');


      #query qurban by asrama where pesanan = disaksikan
      $qurban_asrama_disaksikan = \DB::table('order_qurban_details')
                                       ->select('kotas.id as kotas_id',
                                                'kotas.nama_kota as nama_kota',
                                                $domba_a,
                                                $domba_b,
                                                $sapi_super,
                                                $sapi_standar,
                                                $sapi_r_a,
                                                $sapi_r_b,
                                                $domba_hidup,
                                                $kambing_hidup,
                                                $sapi_hidup
                                              )
                                       ->join('kotas','kotas.id','=','order_qurban_details.kota_id')
                                       ->groupBy('order_qurban_details.kota_id')
                                       ->orderBy('kotas.nama_kota','asc')
                                       ->paginate(100);
      if($pesanan_id==5){
         $data['text'] = "Bebas";
      }elseif($pesanan_id==4){
          $data['text'] = "Dokumentasi";
      }
      $data['kembali'] = 'distribusi/bebaskota'.$pesanan_id;
      $data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('qurban');
      return view('distribusi.head.kota',$data);
    }

    #detail disaksikan
    public function detailDist($kantor_id,$pesanan_id){
      $data['limit'] = 30;
      $detailDist = \DB::table('order_qurban_details')
                         ->select('order_qurban_details.kwitansi_id as kwitansi_id',
                                  'hewans.name as jenis_hewan',
                                  'order_qurban_details.qty as qty',
                                  'hewans.harga as harga',
                                  'order_qurban_details.pequrban as pequrban',
                                  'pesanans.name as pesanan',
                                  'pembayarans.name as pembayaran',
                                  'kantors.name as kantor',
                                  'order_qurban_details.konversi as konv',
                                  'order_qurban_details.catatan as catatan')
                          ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                          ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
                          ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
                          ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                          ->where('order_qurban_details.pesanan_id','=',$pesanan_id)
                          ->where('order_qurban_details.kantor_id','=',$kantor_id)
                          ->orderBy('hewans.name')
                          ->paginate($data['limit']);

      $data['detailDist'] = $detailDist->setPath('distribusi/detail/{id}');

      if($pesanan_id==5){
         $data['text'] = "Bebas";
         $data['kembali'] = "distribusi/bebas/".$pesanan_id;

      }elseif($pesanan_id==4){
          $data['text'] = "Dokumentasi";
          $data['kembali'] = "distribusi/bebas/".$pesanan_id;
      }elseif($pesanan_id==2){
          $data['text'] = "Disaksikan";
          $data['kembali'] = "distribusi";
      }
      
        if(isset($_GET['hal'])=='fo-pesanan'){
          $data['kembali'] = "fo/pesanan";
      }

      $data['excel'] = "distribusi/excel/".$kantor_id.'/'.$pesanan_id;

      //$data['kembali'] = 'distribusi/detail/'.$kantor_id.'/'.$pesanan_id;
      return view('distribusi.detail.index',$data);
      #return $data['detailDist'];
    }

    #export excell
    public function excel($kantor_id,$pesanan_id){
    //
    if($pesanan_id==5){
       $pesanan = "Bebas";


    }elseif($pesanan_id==4){
        $pesanan = "Dokumentasi";

    }elseif($pesanan_id==2){
        $pesanan = "Disaksikan";

    }

    $kantor = Kantor::find($kantor_id);


    $detailDist = \DB::table('order_qurban_details')
                       ->select('order_qurban_details.kwitansi_id as kwitansi_id',
                                'hewans.name as jenis_hewan',
                                'order_qurban_details.qty as qty',
                                'hewans.harga as harga',
                                'order_qurban_details.pequrban as pequrban',
                                'pesanans.name as pesanan',
                                'pembayarans.name as pembayaran',
                                'kantors.name as kantor',
                                'order_qurban_details.konversi as konv',
                                'order_qurban_details.catatan as catatan')
                        ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                        ->join('pesanans','pesanans.id','=','order_qurban_details.pesanan_id')
                        ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
                        ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                        ->where('order_qurban_details.pesanan_id','=',$pesanan_id)
                        ->where('order_qurban_details.kantor_id','=',$kantor_id)
                        ->orderBy('hewans.name')
                        ->get();

    \Excel::create('Data Qurban '.$pesanan.' '.$kantor->name,function($excel) use ($detailDist)
    {
       $excel->sheet('data qurban',function($sheet) use ($detailDist)
       {

            $row=2;
            $sheet->row(1,array(
                'Data Qurban Pesanan :'.$detailDist[0]->pesanan.', Kantor : '.$detailDist[0]->kantor
              ));
            $sheet->row(2,array(
                'No','No Kwitansi','Jenis Hewan','Qty','Harga','Pequrban','Pesanan Khusus','Pembayaran','Asrama','konversi','Catatan'
              ));

            $no = 1;
            foreach($detailDist as $dd){
                $sheet->row(++$row,array(
                    $no,
                    $dd->kwitansi_id,
                    $dd->jenis_hewan,
                    $dd->qty,
                    $dd->harga,
                    $dd->pequrban,
                    $dd->pesanan,
                    $dd->pembayaran,
                    $dd->kantor,
                    $dd->konv,
                    $dd->catatan,
                  ));
                $no++;
            }
       });
    })->export('xls');

}


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return 'show';
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        return 'edit';
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
