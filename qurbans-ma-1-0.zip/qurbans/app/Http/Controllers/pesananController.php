<?php

namespace App\Http\Controllers;

Use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Pesanan;
use Input;
use Session;
use Validator;

class pesananController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function __construct(){
       $this->middleware('auth');
     }

    public function index()
    {
        //
        $data['limit'] = 10;
        $pesanan = Pesanan::paginate($data['limit']);

        $data['pesanans'] = $pesanan->setPath('pesanan');
        return view('pesanan.index',$data);

    }

    public function validator(array $data)
    {
        //return print_r($data);
        //die;
        $validator = Validator::make($data, [
            'name' => 'required|max:255',
            'aktif'=> 'required',
        ]);

        return $validator;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('pesanan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = $request->all();
        $validator = $this->validator($data);
        if($validator->fails()){
          return redirect ('pesanan/create')
                          ->withErrors($validator)
                          ->withInput();
        }else{
          Pesanan::create($data);
          return redirect('pesanan');
        }


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function edit($id){
         $pesanan = Pesanan::find($id);
         $data['pesanan'] = $pesanan;
         return view('pesanan.edit',$data);
     }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $data = $request->all();
        $validator = $this->validator($data);

        if($validator->fails()){
          return redirect ('pesanan/edit')
                          ->withErrors($validator)
                          ->withInput();
        }else{
          $pesanan = Pesanan::find($id);
          $pesanan->update($data);
          return redirect('pesanan');
        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //K
        $pesanan = Pesanan::find($id);
        $pesanan->delete();
        return redirect('pesanan');
    }

    public function search(Request $request){
      //pencarian
      $keyword = "%".$request['keyword']."%";
      $pesanan = Pesanan::where('name','like',$keyword)->paginate(10);
      $data['pesanans'] = $pesanan->setPath('pesanan');
      return view('pesanan.index',$data);

    }
}
