<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Kota;
use Input;
use Session;
use Validator;

class kotaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function __construct(){
       $this->middleware('auth');
     }

    public function index()
    {
        //
        $data['limit'] = 10;
        $kotas = Kota::orderBy('nama_kota')->paginate($data['limit']);

        $data['kotas'] = $kotas->setPath('kota');
        return view('kota.index',$data);

    }

    public function validator(array $data)
    {
        //return print_r($data);
        //die;
        $validator = Validator::make($data, [
            'nama_kota' => 'required|max:255',
        ]);

        return $validator;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('kota.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = $request->all();
        $validator = $this->validator($data);
        if($validator->fails()){
          return redirect ('kota/create')
                          ->withErrors($validator)
                          ->withInput();
        }else{
          Kota::create($data);
          return redirect('kota');
        }


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function edit($id){
         $kota = Kota::find($id);
         $data['kota'] = $kota;
         return view('kota.edit',$data);
     }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $data = $request->all();
        $validator = $this->validator($data);

        if($validator->fails()){
          return redirect ('kota/edit')
                          ->withErrors($validator)
                          ->withInput();
        }else{
          $kota = Kota::find($id);
          $kota->update($data);
          return redirect('kota');
        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //K
        $kota = Kota::find($id);
        $kota->delete();
        return redirect('kota');
    }

    public function search(Request $request){
      //pencarian
      $keyword = "%".$request['keyword']."%";
      $kotas = Kota::where('nama_kota','like',$keyword)->paginate(10);
      $data['kotas'] = $kotas->setPath('kota');
      return view('kota.index',$data);

    }
}
