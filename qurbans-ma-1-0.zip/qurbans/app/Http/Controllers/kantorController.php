<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Kantor;
use App\Kota;
use Input;
use Session;
use Validator;

class kantorController extends Controller
{  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */

   public function __construct(){
     $this->middleware('auth');
   }

  public function index()
  {
      //
      $data['limit'] = 10;
      $kantors = Kantor::orderBy('name','asc')->paginate($data['limit']);

      $data['kantors'] = $kantors->setPath('kantor');
      return view('kantor.index',$data);

  }

  public function validator(array $data)
  {
      //return print_r($data);
      //die;
      $validator = Validator::make($data, [
          'name' => 'required|max:255',
          'phone' => 'required',
          'email' => 'email',
          'alamat' => 'required',
          'id_kota' => 'required'
      ]);

      return $validator;

  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      //
      $kotas = Kota::orderBy('nama_kota', 'asc')->lists('nama_kota','id');
      $data['kotas'] = $kotas;
      return view('kantor.create',compact('kotas',$kotas));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);
      if($validator->fails()){
        return redirect ('kantor/create')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        Kantor::create($data);
        return redirect('kantor');
      }


  }


  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
   public function edit($id){
       $kantor = Kantor::find($id);
       $kotas = Kota::orderBy('nama_kota', 'asc')->lists('nama_kota','id');
       $data['kantor'] = $kantor;
       return view('kantor.edit',compact('kotas',$kotas))->with($data);
   }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);

      if($validator->fails()){
        return redirect ('kantor/edit')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        $kantor = Kantor::find($id);
        $kantor->update($data);
        return redirect('kantor');
      }


  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
      //K
      $kantor = Kantor::find($id);
      $kantor->delete();
      return redirect('kantor');
  }

  public function search(Request $request){
    //pencarian
    $keyword = "%".$request['keyword']."%";
    $kantors = Kantor::where('name','like',$keyword)->paginate(10);
    $data['kantors'] = $kantors->setPath('kantor');
    return view('kantor.index',$data);

  }
}
