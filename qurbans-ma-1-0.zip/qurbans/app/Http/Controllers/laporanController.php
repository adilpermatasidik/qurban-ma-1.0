<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Order_qurban_detail;

class laporanController extends Controller
{

  public function __construct(){
    $this->middleware('auth');
  }

  public function hewanqurban(){

    #cari jumlah domba A
    $domba_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                         FROM order_qurban_details
                         JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                         JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                         WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.kantor_id = kantors.id) as domba_a');
    #cari jumlah domba b
    $domba_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 6 AND order_qurban_details.kantor_id = kantors.id) as domba_b');

    #cari jumlah sapi sapi_super
    $sapi_super = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 1 AND order_qurban_details.kantor_id = kantors.id) as sapi_super');

    #cari jumlah sapi standar
    $sapi_standar = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_standar');

    #cari jumlah sapi 1/7 A
    $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 3 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_a');

    #cari jumlah sapi 1/7 B
    $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 4 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_b');

    #cari jumlah domba_hidup
    $domba_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 9 AND order_qurban_details.kantor_id = kantors.id) as domba_hidup');

    #cari jumlah kambing_hidup
    $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(order_qurban_details.qty),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 8 AND order_qurban_details.kantor_id = kantors.id) as kambing_hidup');

    #cari jumlah kambing_hidup
    $sapi_hidup = \DB::raw('(select ifnull(sum(order_qurban_details.qty),0)
                            from order_qurban_details
                            join hewans on hewans.id = order_qurban_details.hewan_id
                            join pesanans on pesanans.id = order_qurban_details.pesanan_id
                            where hewans.id = 7 and order_qurban_details.kantor_id = kantors.id) as sapi_hidup');


    #query qurban by asrama where pesanan = disaksikan
    $qurban_asrama = \DB::table('order_qurban_details')
                                     ->select('kantors.id as kantor_id',
                                              'kantors.name as nama_kantor',
                                              'kotas.nama_kota as nama_kota',

                                              $domba_a,
                                              $domba_b,
                                              $sapi_super,
                                              $sapi_standar,
                                              $sapi_r_a,
                                              $sapi_r_b,
                                              $domba_hidup,
                                              $kambing_hidup,
                                              $sapi_hidup
                                            )
                                     ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                     ->join('kotas','kotas.id','=','kantors.id_kota')
                                     ->groupBy('order_qurban_details.kantor_id')
                                     ->orderBy('kantors.name','asc')
                                     ->get();
                                     #->paginate(50);

    $data['text'] = "Disaksikan";
    $data['pesanan_id'] = 2;
    $data['kembali'] = 'distribusi';
    #$data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('nominal');
    $data['qurban_asrama_disaksikan'] = $qurban_asrama;

    #query graphic bulat qurban by nama hewan
    $selec_raw_hewan = \DB::raw('hewans.name as nama_hewan,
                              sum(order_qurban_details.qty) as qty');
    $grap_quban_by_hewan = \DB::table('order_qurban_details')
                                ->select($selec_raw_hewan)
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->groupBy('order_qurban_details.hewan_id')
                                ->orderBy('hewans.name')
                                ->get();
    $data['qurban_by_hewan'] = $grap_quban_by_hewan;
    #end query

    return view('laporan.hewanqurban',$data);
  }

  public function grapdonasi(){
    #query graphic qurban by tanggal
    $selec_raw_date = \DB::raw('sum(order_qurban_details.qty) as qty,
                                sum(hewans.harga) as nominal,
                                DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d") as date');
    $timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');

    $grap_quban_by_tanggal = \DB::table('order_qurban_details')
                                ->select($selec_raw_date)
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->groupBy($timestamp_to_date)
                                ->get();
    $data['qurban_by_date'] = $grap_quban_by_tanggal;
    #end query

    return view('laporan.grapdonasi',$data);
  }

  public function grappequrban(){
    #query graphic qurban by tanggal
    $selec_raw_date = \DB::raw('sum(order_qurban_details.qty) as qty,
                                sum(hewans.harga) as nominal,
                                DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d") as date');
    $timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');
    #$grap_quban_by_tanggal = Order_qurban_detail::select($selec_raw_date)
    $grap_quban_by_tanggal = \DB::table('order_qurban_details')
                                ->select($selec_raw_date)
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->groupBy($timestamp_to_date)
                                ->get();
    $data['qurban_by_date'] = $grap_quban_by_tanggal;
    #end query

    return view('laporan.pequrban',$data);
  }

  public function nominal(){

    #cari jumlah domba A
    $domba_a = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                         FROM order_qurban_details
                         JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                         JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                         WHERE order_qurban_details.hewan_id = 5 AND order_qurban_details.kantor_id = kantors.id) as domba_a');
    #cari jumlah domba b
    $domba_b = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 6 AND order_qurban_details.kantor_id = kantors.id) as domba_b');

    #cari jumlah sapi sapi_super
    $sapi_super = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 1 AND order_qurban_details.kantor_id = kantors.id) as sapi_super');

    #cari jumlah sapi standar
    $sapi_standar = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 2 AND order_qurban_details.kantor_id = kantors.id) as sapi_standar');

    #cari jumlah sapi 1/7 A
    $sapi_r_a = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 3 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_a');

    #cari jumlah sapi 1/7 B
    $sapi_r_b = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 4 AND order_qurban_details.kantor_id = kantors.id) as sapi_r_b');

    #cari jumlah domba_hidup
    $domba_hidup = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                        FROM order_qurban_details
                        JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                        JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                        WHERE hewans.id = 9 AND order_qurban_details.kantor_id = kantors.id) as domba_hidup');

    #cari jumlah kambing_hidup
    $kambing_hidup = \DB::raw('(SELECT IFNULL(sum(hewans.harga),0)
                            FROM order_qurban_details
                            JOIN hewans ON hewans.id = order_qurban_details.hewan_id
                            JOIN pesanans ON pesanans.id = order_qurban_details.pesanan_id
                            WHERE hewans.id = 8 AND order_qurban_details.kantor_id = kantors.id) as kambing_hidup');

    #cari jumlah kambing_hidup
    $sapi_hidup = \DB::raw('(select ifnull(sum(hewans.harga),0)
                            from order_qurban_details
                            join hewans on hewans.id = order_qurban_details.hewan_id
                            join pesanans on pesanans.id = order_qurban_details.pesanan_id
                            where hewans.id = 7 and order_qurban_details.kantor_id = kantors.id) as sapi_hidup');


    #query qurban by asrama where pesanan = disaksikan
    $qurban_asrama_disaksikan = \DB::table('order_qurban_details')
                                     ->select('kantors.id as kantor_id',
                                              'kantors.name as nama_kantor',
                                              'kotas.nama_kota as nama_kota',

                                              $domba_a,
                                              $domba_b,
                                              $sapi_super,
                                              $sapi_standar,
                                              $sapi_r_a,
                                              $sapi_r_b,
                                              $domba_hidup,
                                              $kambing_hidup,
                                              $sapi_hidup
                                            )
                                     ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                     ->join('kotas','kotas.id','=','kantors.id_kota')
                                     ->groupBy('order_qurban_details.kantor_id')
                                     ->orderBy('kantors.name','asc')
                                     ->get();
                                     #->paginate(50);

    $data['text'] = "Disaksikan";
    $data['pesanan_id'] = 2;
    $data['kembali'] = 'distribusi';
    #$data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan->setPath('nominal');
    $data['qurban_asrama_disaksikan'] = $qurban_asrama_disaksikan;
    return view('laporan.nominal',$data);
  }

  public function grapasrama($jenis){
    if($jenis == 'qty'){
      $ordersum = \DB::raw('sum(order_qurban_details.qty)');
    }elseif($jenis == 'nominal') {
      $ordersum = \DB::raw('sum(hewans.harga)');

    }
    #query graphic qurban by asrama
    $selec_raw_date = \DB::raw('kantors.name as kantor,
                                sum(order_qurban_details.qty) as qty,
                                sum(hewans.harga) as nominal');
    #$timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');
    $grap_qurban_by_asrama = \DB::table('order_qurban_details')
                                ->select($selec_raw_date)
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->join('kantors','kantors.id','=','order_qurban_details.kantor_id')
                                ->groupBy('order_qurban_details.kantor_id')
                                ->orderBy($ordersum,'desc')
                                ->get();
    $data['qurban_by_asrama'] = $grap_qurban_by_asrama;
    $data['jenis'] = $jenis;
    $data['text'] = ucwords($jenis);
    #end query

    return view('laporan.asrama',$data);
  }

  public function grappayment($jenis){
    #query graphic qurban by asrama
    $selec_raw_date = \DB::raw('pembayarans.name as payment,
                                sum(order_qurban_details.qty) as qty,
                                sum(hewans.harga) as harga'
                              );
    #$timestamp_to_date = \DB::raw('DATE_FORMAT(order_qurban_details.created_at,"%Y-%m-%d")');

    $grap_qurban_by_payment = \DB::table('order_qurban_details')
                                ->select($selec_raw_date)
                                ->join('pembayarans','pembayarans.id','=','order_qurban_details.payment_id')
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->groupBy('order_qurban_details.payment_id')
                                ->get();
    $data['qurban_by_payment'] = $grap_qurban_by_payment;
    $data['jenis'] = $jenis;
    $data['text'] = ucwords($jenis);
    #end query

    return view('laporan.payment',$data);
  }

  public function graprating($jenis){
  
  if($jenis=='nominal'){
    #query graphic qurban by asrama
    $selec_raw_date = \DB::raw('donaturs.name as donatur,
                                sum(hewans.harga) as harga'
                              );
    $field_sum = \DB::raw('sum(hewans.harga)');
    }
    elseif($jenis=='nominal'){
    $selec_raw_date = \DB::raw('donaturs.name as donatur,
                                sum(order_qurban_details.qty) as qty'
                              );
    $field_sum = \DB::raw('sum(order_qurban_details.qty)');
    }
  

    $grap_qurban_by_rating = \DB::table('order_qurban_details')
                                ->select($selec_raw_date)
                                ->join('donaturs','donaturs.id','=','order_qurban_details.donatur_id')
                                ->join('hewans','hewans.id','=','order_qurban_details.hewan_id')
                                ->groupBy('order_qurban_details.donatur_id')
                                ->orderBy($field_sum,'desc')
                                ->paginate(10);
    $data['qurban_by_rating'] = $grap_qurban_by_rating;
    $data['jenis'] = $jenis;
    $data['text'] = ucwords($jenis);
    #end query

    return view('laporan.rating',$data);
  }


}
