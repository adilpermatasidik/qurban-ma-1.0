<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Hewan;
use Input;
use Session;
use Validator;

class hewanController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */

   public function __construct(){
     $this->middleware('auth');
   }

  public function index()
  {
      //
      $data['limit'] = 10;
      $hewans = Hewan::paginate($data['limit']);

      $data['hewans'] = $hewans->setPath('hewan');
      return view('hewan.index',$data);

  }

  public function validator(array $data)
  {
      //return print_r($data);
      //die;
      $validator = Validator::make($data, [
          'name' => 'required|max:255',
          'berat' => 'required',
          'harga' => 'required',
          'jenis' => 'required',

      ]);

      return $validator;

  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      //
      return view('hewan.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);
      if($validator->fails()){
        return redirect ('hewan/create')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        Hewan::create($data);
        return redirect('hewan');
      }


  }


  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
   public function edit($id){
       $hewan = Hewan::find($id);
       $data['hewan'] = $hewan;
       return view('hewan.edit',$data);
   }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);

      if($validator->fails()){
        return redirect ('hewan/edit')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        $hewan = Hewan::find($id);
        $hewan->update($data);
        return redirect('hewan');
      }


  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
      //K
      $hewan = Hewan::find($id);
      $hewan->delete();
      return redirect('hewan');
  }

  public function search(Request $request){
    //pencarian
    $keyword = "%".$request['keyword']."%";
    $hewans = Hewan::where('name','like',$keyword)->paginate(10);
    $data['hewans'] = $hewans->setPath('hewan');
    return view('hewan.index',$data);

  }
}
