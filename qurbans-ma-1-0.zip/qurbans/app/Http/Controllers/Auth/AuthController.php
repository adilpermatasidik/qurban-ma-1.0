<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use App\Kantor;
use Illuminate\Http\Request;
use App\Http\Requests;
use Input;
use Session;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */

    protected $redirectPath = '/dashboard';

    public function __construct()
    {
        $this->middleware('guest', ['except' => array('getLogout','getRegister','postRegister','index','edit','update','search','destroy','simpan','addUser')]);

    }

    public function index(){
        $data['limit'] = 10;
        //$users = User::paginate($data['limit']);

        $users = \DB::table('users')
                    ->select('users.id','users.name','users.email','users.role','users.id_kantor','kantors.name as kantor')
                    ->join('kantors','kantors.id','=','users.id_kantor')
                    ->orderBy('users.name','asc')
                    ->paginate($data['limit']);

        $data['users'] = $users->setPath('index');
        return view('auth.index',$data);
    }


    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        //return print_r($data);
        //die;
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
            'role' => 'required|max:255',
            'id_kantor' => 'required|max:11',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {

        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'role'=> $data['role'],
            'id_kantor' =>$data['id_kantor'],
        ]);


    }

    protected function edit($id){
      $user = User::find($id);
      $kantors = Kantor::orderBy('name', 'asc')->lists('name','id');
      $data['user'] = $user;
      return view('auth.edit',compact('kantors',$kantors))->with($data);

      //  $user = User::find($id);
      //  $data['user'] = $user;
      //  return view('auth.edit',$data);
    }

    protected function addUser(){
        $kantors = Kantor::orderBy('name', 'asc')->lists('name','id');
        return view('auth.register',compact('kantors',$kantors));
    }

    protected function simpan(Request $request)
    {

        $data = $request->all();

        $data = array(
                    'name' => Input::get('name'),
                    'email' => Input::get('email'),
                    'password' => bcrypt(Input::get('password')),
                    'role' => Input::get('role'),
                    'id_kantor' => Input::get('id_kantor')
                    );


        $user = User::create($data);
        return redirect('auth/index');
    }

     protected function update(Request $request, $id)
    {

        $data = $request->all();
        if(Input::get('password') == ""){
             $data = array(
                    'name' => Input::get('name'),
                    'email' => Input::get('email'),
                    'role' => Input::get('role'),
                    'id_kantor' => Input::get('id_kantor')
                    );
        }
        else{
        $data = array(
                    'name' => Input::get('name'),
                    'email' => Input::get('email'),
                    'password' => bcrypt(Input::get('password')),
                    'role' => Input::get('role'),
                    'id_kantor' => Input::get('id_kantor')
                    );
         }

        $user = User::find($id);
        $user->update($data);
        return redirect('auth/index');
    }

    protected function search(Request $request)
    {
    
    $data['limit'] = 10;
        //pencarian
        $field = $request['field'];
        $keyword = "%".$request['keyword']."%";
        //echo "$field $keyword";
        //die;
        //$users = User::where($field,'like',$keyword)->paginate(10);
      	
      	 $users = \DB::table('users')
                    ->select('users.id','users.name','users.email','users.role','users.id_kantor','kantors.name as kantor')
                    ->join('kantors','kantors.id','=','users.id_kantor')
                    ->where($field,'like',$keyword)
                    ->orderBy('users.name','asc')
                    ->paginate($data['limit']);  
        
        $data['users'] = $users->setPath('');
        return view('auth/index',$data);

    }

        protected function destroy($id)
    {
        //
        $user = User::find($id);
        $user->delete();
        return redirect('auth/index');
    }
}
