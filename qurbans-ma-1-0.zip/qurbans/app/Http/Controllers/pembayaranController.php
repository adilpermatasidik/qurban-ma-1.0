<?php

namespace App\Http\Controllers;

Use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Pembayaran;
use Input;
use Session;
use Validator;

class pembayaranController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */

   public function __construct(){
     $this->middleware('auth');
   }

  public function index()
  {
      //
      $data['limit'] = 10;
      $pembayaran = Pembayaran::paginate($data['limit']);

      $data['pembayarans'] = $pembayaran->setPath('pembayaran');
      return view('pembayaran.index',$data);

  }

  public function validator(array $data)
  {
      //return print_r($data);
      //die;
      $validator = Validator::make($data, [
          'name' => 'required|max:255',
      ]);

      return $validator;

  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      //
      return view('pembayaran.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);
      if($validator->fails()){
        return redirect ('pembayaran/create')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        Pembayaran::create($data);
        return redirect('pembayaran');
      }


  }


  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
   public function edit($id){
       $pembayaran = Pembayaran::find($id);
       $data['pembayaran'] = $pembayaran;
       return view('pembayaran.edit',$data);
   }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
      //
      $data = $request->all();
      $validator = $this->validator($data);

      if($validator->fails()){
        return redirect ('pembayaran/edit')
                        ->withErrors($validator)
                        ->withInput();
      }else{
        $pembayaran = Pembayaran::find($id);
        $pembayaran->update($data);
        return redirect('pembayaran');
      }


  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
      //K
      $pembayaran = Pembayaran::find($id);
      $pembayaran->delete();
      return redirect('pembayaran');
  }

  public function search(Request $request){
    //pencarian
    $keyword = "%".$request['keyword']."%";
    $pembayaran = Pembayaran::where('name','like',$keyword)->paginate(10);
    $data['pembayarans'] = $pembayaran->setPath('pembayaran');
    return view('pembayaran.index',$data);

  }
}
