<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

#Route::resource('dashboard2','dashboardController');



Route::get('/', 'dashboardController@index');
Route::get('dashboard', 'dashboardController@index');
Route::get('fo/pesanan','dashboardController@pagePesanan');


//transaksi distribusi head
Route::get('distribusi', 'distribusiController@index');
Route::get('distribusi/kota', 'distribusiController@disaksikanKota');
Route::get('distribusi/bebas/{pesanan_id}', 'distribusiController@distBebas');
Route::get('distribusi/bebaskota/{pesanan_id}', 'distribusiController@distBebasKota');
Route::get('distribusi/detail/{kantor_id}/{pesanan_id}', 'distribusiController@detailDist');
Route::get('distribusi/excel/{kantor_id}/{pesanan_id}', 'distribusiController@excel');

//laporan
Route::get('laporan/hewanqurban','laporanController@hewanqurban');
Route::get('laporan/nominal','laporanController@nominal');

Route::get('laporan/kota', function () {
    return view('laporan.kota');
});

Route::get('laporan/distribusi', function () {
    return view('laporan.distribusi');
});

Route::get('laporan/payment/{jenis}','laporanController@grappayment');

Route::get('laporan/grapdonasi','laporanController@grapdonasi');

Route::get('laporan/pequrban','laporanController@grappequrban');

Route::get('laporan/asrama/{jenis}','laporanController@grapasrama');

Route::get('laporan/rating/{jenis}','laporanController@graprating');


// Authentication routes...
Route::get('auth/login', 'Auth\AuthController@getLogin');
Route::post('auth/login', 'Auth\AuthController@postLogin');
Route::get('auth/logout', 'Auth\AuthController@getLogout');

// Registration routes...
Route::get('auth/register', 'Auth\AuthController@getRegister');
//Route::post('auth/register', 'Auth\AuthController@postRegister');
Route::get('auth/index', 'Auth\AuthController@index');
Route::get('auth/edit/{id}', 'Auth\AuthController@edit');
Route::patch('auth/update/{id}', 'Auth\AuthController@update');
Route::post('auth/search', 'Auth\AuthController@search');
Route::get('auth/destroy/{id}', 'Auth\AuthController@destroy');
Route::post('auth/simpan', 'Auth\AuthController@simpan');
Route::get('auth/adduser', 'Auth\AuthController@addUser');

//kota
Route::resource('kota','kotaController');
Route::post('kota/search','kotaController@search');
Route::get('kota/destroy/{id}','kotaController@destroy');

//pesanan
Route::resource('pesanan','pesananController');
Route::post('pesanan/search','pesananController@search');
Route::get('pesanan/destroy/{id}','pesananController@destroy');

//pembayaran
Route::resource('pembayaran','pembayaranController');
Route::post('pembayaran/search','pembayaranController@search');
Route::get('pembayaran/destroy/{id}','pembayaranController@destroy');

//hewan Qurban
Route::resource('hewan','hewanController');
Route::post('hewan/search','hewanController@search');
Route::get('hewan/destroy/{id}','hewanController@destroy');

//kantor
Route::resource('kantor','kantorController');
Route::post('kantor/search','kantorController@search');
Route::get('kantor/destroy/{id}','kantorController@destroy');


//donatur
Route::resource('donatur','donaturController');
Route::post('donatur/search','donaturController@search');
Route::get('donatur/destroy/{id}','donaturController@destroy');
Route::get('donatur/tampil/{id}','donaturController@tampil');

//transaksi order qurban
Route::resource('qurban','orderController');
Route::post('qurban/search','orderController@search');
Route::get('qurban/destroy/{id}','orderController@destroy');
Route::get('qurban/add/{id}','orderController@add');
Route::get('qurban/buatdonasi/{id}','orderController@buatdonasi');
Route::get('qurban/addItem/{id}','orderController@addItem');
Route::get('qurbanvalidasi','orderController@validasi');
Route::get('qurbanvalid/{id}','orderController@valid');
Route::post('qurbanvalid/cari','orderController@cari');
Route::get('qurbanvalidasi/excel','orderController@excel');
