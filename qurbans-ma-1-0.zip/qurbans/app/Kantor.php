<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kantor extends Model
{
  //allow field
  protected $fillable = ['name','phone','email','alamat','id_kota'];

}
