<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pesanan extends Model
{
  //allow field
  protected $fillable = ['name','aktif'];
}
