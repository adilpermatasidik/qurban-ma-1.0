<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donatur extends Model
{
  //allow field
  protected $fillable = ['title','name','phone','email','alamat','id_user','id_kantor'];

  public function qurban_by_id()
  {
      return  $this->hasMany('App\Order_qurban_detail');
  }

}
