<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_qurban_detail extends Model
{
  //enable field from outside
  protected $fillable = ['kwitansi_id','donatur_id','hewan_id','qty','konversi','pequrban','pesanan_id','payment_id','user_id','kantor_id','distribusi_id','kota_id','catatan','valid'];
}
